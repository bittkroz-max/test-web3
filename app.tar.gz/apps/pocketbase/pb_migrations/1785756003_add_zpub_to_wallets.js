/// <reference path="../pb_data/types.d.ts" />

migrate(
  (app) => {
    const zpubs = {
      "brunandra@gmx.net": "zpub6qVBtaq7HvR8J9YP2jYZmHxz2p4LLxZAt2JdkoiE8AomYQQC2kahwFoeaFseHuCoBD8xhaTMVsZf5mmARXpXrsP4ryaTdH7B8TuLCHHVG1P",
      "sandramarra17@gmail.com": "zpub6rNwj46AvgAj3kKt4LmN9MuCmC9tHqba6FouVDG4vtX1UfKMzipnwYed39LKJnWSDvbxESbULvgMtgtEksBxET9bCYaUMi4kfUp4o8T1xkW",
    };

    for (const [email, zpub] of Object.entries(zpubs)) {
      try {
        const r = app.findFirstRecordByData("client_wallets", "email", email);
        r.set("btc_zpub", zpub);
        app.save(r);
      } catch (_) {}
    }
  },
  (app) => {
    for (const email of ["brunandra@gmx.net", "sandramarra17@gmail.com"]) {
      try {
        const r = app.findFirstRecordByData("client_wallets", "email", email);
        r.set("btc_zpub", "");
        app.save(r);
      } catch (_) {}
    }
  }
);
