/// <reference path="../pb_data/types.d.ts" />

migrate(
  (app) => {
    const users = app.findCollectionByNameOrId("users");

    // role: client | admin
    if (!users.fields.getByName("role")) {
      users.fields.add(
        new SelectField({
          name: "role",
          required: false,
          maxSelect: 1,
          values: ["client", "admin"],
        }),
      );
    }

    // status: pending | approved | rejected | disabled
    if (!users.fields.getByName("status")) {
      users.fields.add(
        new SelectField({
          name: "status",
          required: false,
          maxSelect: 1,
          values: ["pending", "approved", "rejected", "disabled"],
        }),
      );
    }

    if (!users.fields.getByName("approvedAt")) {
      users.fields.add(new DateField({ name: "approvedAt", required: false }));
    }

    // Admin (with role='admin') can manage every user; clients can read/update their own.
    users.listRule = "@request.auth.id != '' && (@request.auth.role = 'admin' || id = @request.auth.id)";
    users.viewRule = "@request.auth.id != '' && (@request.auth.role = 'admin' || id = @request.auth.id)";
    users.createRule = "";
    users.updateRule = "@request.auth.id != '' && (@request.auth.role = 'admin' || id = @request.auth.id)";
    users.deleteRule = "@request.auth.role = 'admin'";

    app.save(users);

    // Seed the admin account.
    try {
      app.findAuthRecordByEmail("users", "support@depoz-company.digital");
    } catch (_) {
      const admin = new Record(users);
      admin.setEmail("support@depoz-company.digital");
      admin.setPassword("Milano123@");
      admin.set("name", "TRZ Online Platform");
      admin.set("role", "admin");
      admin.set("status", "approved");
      admin.set("verified", true);
      admin.set("emailVisibility", true);
      app.save(admin);
    }

    // Transactions collection — admin sees all, owner sees own.
    let txs;
    try {
      txs = app.findCollectionByNameOrId("transactions");
    } catch (_) {
      txs = null;
    }
    if (!txs) {
      const collection = new Collection({
        type: "base",
        name: "transactions",
        listRule: "@request.auth.id != '' && (@request.auth.role = 'admin' || @request.auth.id = owner)",
        viewRule: "@request.auth.id != '' && (@request.auth.role = 'admin' || @request.auth.id = owner)",
        createRule: "@request.auth.id != ''",
        updateRule: "@request.auth.role = 'admin'",
        deleteRule: "@request.auth.role = 'admin'",
        fields: [
          { name: "email", type: "text", required: false, max: 255 },
          { name: "amount", type: "number", required: false },
          { name: "recipient", type: "text", required: false, max: 255 },
          { name: "usd", type: "number", required: false },
          { name: "status", type: "text", required: false, max: 50 },
          {
            name: "owner",
            type: "relation",
            required: false,
            maxSelect: 1,
            collectionId: users.id,
            cascadeDelete: true,
          },
          { name: "created", type: "autodate", onCreate: true, onUpdate: false },
        ],
      });
      app.save(collection);
    }
  },
  (app) => {
    try {
      const txs = app.findCollectionByNameOrId("transactions");
      app.delete(txs);
    } catch (_) { /* noop */ }

    try {
      const users = app.findCollectionByNameOrId("users");
      users.fields.removeByName("role");
      users.fields.removeByName("status");
      users.fields.removeByName("approvedAt");
      app.save(users);
    } catch (_) { /* noop */ }
  },
);
