/// <reference path="../pb_data/types.d.ts" />

migrate(
  (app) => {
    let existing;
    try {
      existing = app.findCollectionByNameOrId("kyc_documents");
    } catch (_) {
      existing = null;
    }
    if (existing) return;

    const users = app.findCollectionByNameOrId("users");

    const collection = new Collection({
      type: "base",
      name: "kyc_documents",
      // Owner can create/read own; admin can read + update (approve/reject) all.
      listRule: "@request.auth.id != '' && (@request.auth.role = 'admin' || @request.auth.id = owner)",
      viewRule: "@request.auth.id != '' && (@request.auth.role = 'admin' || @request.auth.id = owner)",
      createRule: "@request.auth.id != '' && @request.auth.id = owner",
      updateRule: "@request.auth.role = 'admin'",
      deleteRule: "@request.auth.role = 'admin'",
      fields: [
        {
          name: "email",
          type: "text",
          required: false,
          max: 255,
        },
        {
          name: "documents",
          type: "file",
          required: true,
          maxSelect: 5,
          maxSize: 10485760,
          mimeTypes: [
            "image/jpeg",
            "image/png",
            "image/webp",
            "image/gif",
            "application/pdf",
          ],
        },
        {
          name: "docType",
          type: "select",
          required: false,
          maxSelect: 1,
          values: ["id_card", "drivers_license", "passport"],
        },
        {
          name: "status",
          type: "select",
          required: false,
          maxSelect: 1,
          values: ["pending", "approved", "rejected"],
        },
        {
          name: "reviewedAt",
          type: "date",
          required: false,
        },
        {
          name: "owner",
          type: "relation",
          required: true,
          maxSelect: 1,
          collectionId: users.id,
          cascadeDelete: true,
        },
        { name: "created", type: "autodate", onCreate: true, onUpdate: false },
        { name: "updated", type: "autodate", onCreate: true, onUpdate: true },
      ],
      indexes: [
        "CREATE INDEX idx_kyc_owner ON kyc_documents (owner)",
        "CREATE INDEX idx_kyc_status ON kyc_documents (status)",
      ],
    });
    app.save(collection);
  },
  (app) => {
    try {
      const collection = app.findCollectionByNameOrId("kyc_documents");
      app.delete(collection);
    } catch (_) { /* noop */ }
  },
);
