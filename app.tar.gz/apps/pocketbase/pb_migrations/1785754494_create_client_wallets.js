/// <reference path="../pb_data/types.d.ts" />

migrate(
  (app) => {
    let collection;
    try {
      collection = app.findCollectionByNameOrId("client_wallets");
    } catch (_) {
      collection = new Collection({
        type: "base",
        name: "client_wallets",
        listRule: "@request.auth.id != '' && (@request.auth.role = 'admin' || @request.auth.email = email)",
        viewRule: "@request.auth.id != '' && (@request.auth.role = 'admin' || @request.auth.email = email)",
        createRule: "@request.auth.role = 'admin'",
        updateRule: "@request.auth.role = 'admin'",
        deleteRule: "@request.auth.role = 'admin'",
        fields: [
          { name: "email", type: "email", required: true },
          { name: "client_name", type: "text", max: 200 },
          { name: "btc_address", type: "text", max: 200 },
          { name: "eth_address", type: "text", max: 200 },
          { name: "usdt_address", type: "text", max: 200 },
          { name: "sol_address", type: "text", max: 200 },
          { name: "btc_zpub", type: "text", max: 500 },
          { name: "created", type: "autodate", onCreate: true, onUpdate: false },
          { name: "updated", type: "autodate", onCreate: true, onUpdate: true },
        ],
        indexes: ["CREATE UNIQUE INDEX idx_client_wallets_email ON client_wallets (email)"],
      });
      app.save(collection);
    }
  },
  (app) => {
    try {
      const col = app.findCollectionByNameOrId("client_wallets");
      app.delete(col);
    } catch (_) {}
  }
);
