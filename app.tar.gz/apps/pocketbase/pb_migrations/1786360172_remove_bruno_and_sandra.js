/// <reference path="../pb_data/types.d.ts" />

migrate(
  (app) => {
    const emailsToRemove = ["brunandra@gmx.net", "sandramarra17@gmail.com"];

    for (const email of emailsToRemove) {
      // Delete wallet records
      try {
        const wallet = app.findFirstRecordByData("client_wallets", "email", email);
        app.delete(wallet);
        console.log(`[cleanup] Deleted wallet for ${email}`);
      } catch (_) {
        console.log(`[cleanup] No wallet found for ${email}`);
      }

      // Delete KYC documents
      try {
        const kycs = app.findRecordsByFilter("kyc_documents", `email = '${email}'`);
        for (const kyc of kycs) {
          app.delete(kyc);
        }
        console.log(`[cleanup] Deleted KYC documents for ${email}`);
      } catch (_) {}

      // Delete transactions
      try {
        const txs = app.findRecordsByFilter("transactions", `email = '${email}'`);
        for (const tx of txs) {
          app.delete(tx);
        }
        console.log(`[cleanup] Deleted transactions for ${email}`);
      } catch (_) {}

      // Delete user account
      try {
        const user = app.findFirstRecordByFilter("users", `email = '${email}'`);
        app.delete(user);
        console.log(`[cleanup] Deleted user account for ${email}`);
      } catch (_) {
        console.log(`[cleanup] No user account found for ${email}`);
      }
    }
  },
  (app) => {
    // No-op down: deleted data cannot be restored
  }
);
