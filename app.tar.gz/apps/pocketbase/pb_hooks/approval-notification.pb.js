/// <reference path="../pb_data/types.d.ts" />

// Sends the client-approval / client-rejection emails server-side, so the
// recipient is always determined by the record being updated (the client),
// never by whatever the browser happened to pass in. This fixes the bug
// where the "approval" email was landing in the admin inbox instead of the
// client's inbox.

const ADMIN_EMAIL = "support@delfinitx.com";
const LOGIN_URL = "https://delfinitx.com/login";

// Build the "from" field exactly like PocketBase's own built-in auth
// emails do: start from the platform-configured sender (settings.meta),
// then only override the display name — the same approach used by
// onMailerRecordVerificationSend in branded-verification-email.pb.js,
// which only mutates e.message.from.name and leaves the address untouched.
function brandedFrom() {
  let address = "";
  try {
    address = $app.settings().meta.senderAddress || "";
  } catch (_) {
    address = "";
  }
  return address ? { name: "delfinitx", address: address } : { name: "delfinitx" };
}

function sendApprovalEmails(record) {
  const email = record.getString("email");
  const name = record.getString("name") || "Client";

  // 1) Email to the CLIENT who was approved.
  try {
    $app.newMailClient().send(new MailerMessage({
      from: brandedFrom(),
      to: [{ address: email }],
      subject: "Account Approved - delfinitx",
      html: `
        <div style="background-color:#0b0f14;padding:32px 16px;font-family:-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;">
          <div style="max-width:520px;margin:0 auto;background-color:#12161d;border:1px solid #232a35;border-radius:16px;overflow:hidden;">
            <div style="padding:28px 32px 20px;text-align:center;border-bottom:1px solid #232a35;">
              <div style="display:inline-flex;align-items:center;justify-content:center;width:48px;height:48px;border-radius:12px;background-color:rgba(243,186,47,0.12);margin-bottom:12px;">
                <span style="font-size:22px;">&#8383;</span>
              </div>
              <p style="margin:0;color:#f3ba2f;font-size:13px;font-weight:700;letter-spacing:0.08em;text-transform:uppercase;">delfinitx</p>
            </div>
            <div style="padding:32px;color:#e6e9ee;">
              <h1 style="margin:0 0 20px;font-size:20px;color:#ffffff;">Account Approved</h1>
              <p style="margin:0 0 16px;font-size:14px;line-height:1.6;color:#aeb6c2;">Dear ${name},</p>
              <p style="margin:0 0 20px;font-size:14px;line-height:1.6;color:#aeb6c2;">
                Congratulations! Your account has been approved. You can now access the wallet.
              </p>
              <div style="text-align:center;margin:0 0 28px;">
                <a href="${LOGIN_URL}" style="display:inline-block;background-color:#f3ba2f;color:#141414;font-weight:700;font-size:14px;text-decoration:none;padding:14px 32px;border-radius:10px;">Login to your wallet</a>
              </div>
              <p style="margin:0 0 24px;font-size:13px;line-height:1.6;color:#6b7280;">
                If you have any questions, please contact our support team.
              </p>
              <p style="margin:0;font-size:14px;line-height:1.6;color:#e6e9ee;">
                Best regards,<br />delfinitx Team
              </p>
            </div>
          </div>
        </div>
      `,
    }));
    $app.logger().info("approval email sent to client", "email", email);
  } catch (err) {
    $app.logger().error("approval email to client failed", "email", email, "err", String(err));
  }

  // 2) Notification to the ADMIN inbox — informational only.
  try {
    $app.newMailClient().send(new MailerMessage({
      from: brandedFrom(),
      to: [{ address: ADMIN_EMAIL }],
      subject: `Customer Approved - ${name}`,
      html: `<p>A new customer has been approved: ${name} (${email}).</p><p>Approved at: ${new Date().toISOString()}</p>`,
    }));
  } catch (err) {
    $app.logger().error("approval notification to admin failed", "err", String(err));
  }
}

function sendRejectionEmails(record) {
  const email = record.getString("email");
  const name = record.getString("name") || "Client";

  // 1) Email to the CLIENT who was rejected.
  try {
    $app.newMailClient().send(new MailerMessage({
      from: brandedFrom(),
      to: [{ address: email }],
      subject: "Account Rejected - delfinitx",
      html: `
        <div style="background-color:#0b0f14;padding:32px 16px;font-family:-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;">
          <div style="max-width:520px;margin:0 auto;background-color:#12161d;border:1px solid #232a35;border-radius:16px;overflow:hidden;">
            <div style="padding:32px;color:#e6e9ee;">
              <h1 style="margin:0 0 20px;font-size:20px;color:#ffffff;">Account Update</h1>
              <p style="margin:0 0 16px;font-size:14px;line-height:1.6;color:#aeb6c2;">Dear ${name},</p>
              <p style="margin:0 0 20px;font-size:14px;line-height:1.6;color:#aeb6c2;">
                Your account application has been rejected. Please contact our support team for more information.
              </p>
              <p style="margin:0;font-size:14px;line-height:1.6;color:#e6e9ee;">
                Best regards,<br />delfinitx Team
              </p>
            </div>
          </div>
        </div>
      `,
    }));
    $app.logger().info("rejection email sent to client", "email", email);
  } catch (err) {
    $app.logger().error("rejection email to client failed", "email", email, "err", String(err));
  }

  // 2) Notification to the ADMIN inbox — informational only.
  try {
    $app.newMailClient().send(new MailerMessage({
      from: brandedFrom(),
      to: [{ address: ADMIN_EMAIL }],
      subject: `Customer Rejected - ${name}`,
      html: `<p>A customer application has been rejected: ${name} (${email}).</p>`,
    }));
  } catch (err) {
    $app.logger().error("rejection notification to admin failed", "err", String(err));
  }
}

onRecordUpdateRequest((e) => {
  const id = e.record.id;
  let oldStatus = null;
  try {
    const old = $app.findRecordById("users", id);
    oldStatus = old.getString("status");
  } catch (_) {
    oldStatus = null;
  }

  // Perform the actual save first. Only send emails once we know the
  // update was accepted and persisted.
  e.next();

  const newStatus = e.record.getString("status");

  if (newStatus === "approved" && oldStatus !== "approved") {
    sendApprovalEmails(e.record);
  } else if (newStatus === "rejected" && oldStatus !== "rejected") {
    sendRejectionEmails(e.record);
  }
}, "users");
