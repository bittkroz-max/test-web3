/// <reference path="../pb_data/types.d.ts" />

// Password-reset email, wired up EXACTLY like the working email-verification
// flow in branded-verification-email.pb.js:
//  - the frontend triggers PocketBase's own BUILT-IN password-reset request
//    (pb.collection('users').requestPasswordReset(email)) instead of a custom
//    route that manually builds and sends a MailerMessage.
//  - this hook only brands the message PocketBase is ALREADY about to send
//    (onMailerRecordPasswordResetSend), the same way
//    onMailerRecordVerificationSend brands the verification email — same
//    trigger family, same "mutate e.message, then e.next()" method, same
//    link-building logic derived from the instance's configured appURL.
// Confirming the reset (setting the new password) also uses PocketBase's
// built-in confirmPasswordReset() on the frontend — no custom /api/custom/*
// routes involved anywhere in this flow anymore.

onMailerRecordPasswordResetSend((e) => {
  let appUrl = "https://delfinitx.com";
  try {
    const configured = $app.settings().meta.appURL || "";
    if (configured) {
      appUrl = configured.replace(/\/hcgi\/.*$/, "").replace(/\/+$/, "");
    }
  } catch (_) {
    // keep fallback
  }

  const link = `${appUrl}/reset-password/${e.meta.token}`;
  const name = e.record.get("name") || "there";

  // Only override the display name — keep the platform-configured sender
  // address intact, exactly like the verification email hook does.
  if (e.message.from && typeof e.message.from === "object") {
    e.message.from.name = "delfinitx";
  } else {
    e.message.from = { name: "delfinitx" };
  }
  e.message.subject = "Reset Your Password - delfinitx";
  e.message.html = `
    <div style="background-color:#0b0f14;padding:32px 16px;font-family:-apple-system,Segoe UI,Roboto,Helvetica,Arial,sans-serif;">
      <div style="max-width:520px;margin:0 auto;background-color:#12161d;border:1px solid #232a35;border-radius:16px;overflow:hidden;">
        <div style="padding:28px 32px 20px;text-align:center;border-bottom:1px solid #232a35;">
          <div style="display:inline-flex;align-items:center;justify-content:center;width:48px;height:48px;border-radius:12px;background-color:rgba(243,186,47,0.12);margin-bottom:12px;">
            <span style="font-size:22px;">&#8383;</span>
          </div>
          <p style="margin:0;color:#f3ba2f;font-size:13px;font-weight:700;letter-spacing:0.08em;text-transform:uppercase;">delfinitx</p>
        </div>
        <div style="padding:32px;color:#e6e9ee;">
          <h1 style="margin:0 0 20px;font-size:20px;color:#ffffff;">Reset your password</h1>
          <p style="margin:0 0 16px;font-size:14px;line-height:1.6;color:#aeb6c2;">Dear ${name},</p>
          <p style="margin:0 0 20px;font-size:14px;line-height:1.6;color:#aeb6c2;">
            We received a request to reset your delfinitx account password. Click the button below to choose a new password. This link is valid for a limited time.
          </p>
          <div style="text-align:center;margin:0 0 28px;">
            <a href="${link}" style="display:inline-block;background-color:#f3ba2f;color:#141414;font-weight:700;font-size:14px;text-decoration:none;padding:14px 32px;border-radius:10px;">Reset Password</a>
          </div>
          <p style="margin:0 0 16px;font-size:13px;line-height:1.6;color:#6b7280;word-break:break-all;">
            Or copy this link into your browser:<br />${link}
          </p>
          <p style="margin:0 0 24px;font-size:13px;line-height:1.6;color:#6b7280;">
            If you did not request this, you can safely ignore this email.
          </p>
          <p style="margin:0;font-size:14px;line-height:1.6;color:#e6e9ee;">
            Best regards,<br />delfinitx Team
          </p>
        </div>
      </div>
    </div>
  `;

  e.next();
}, "users");
