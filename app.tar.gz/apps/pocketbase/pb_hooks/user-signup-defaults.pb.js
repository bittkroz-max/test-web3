/// <reference path="../pb_data/types.d.ts" />

// Force safe defaults on public sign-up so a client cannot self-assign
// role=admin or status=approved through the create request.
onRecordCreateRequest((e) => {
  // `e.requestInfo` is a METHOD on RequestEvent, not a field — using
  // `e.requestInfo.auth` always evaluates to `undefined`. The authenticated
  // requester is exposed directly as `e.auth`.
  const auth = e.auth;
  const isAdmin = !!auth && auth.get("role") === "admin";

  if (!isAdmin) {
    e.record.set("role", "client");
    e.record.set("status", "pending");
  }

  // The users collection hides the `email` field from anyone other than
  // the record owner unless `emailVisibility` is true. Our custom "admin"
  // role is just a regular auth user (not a PocketBase superuser), so
  // without this flag the admin dashboard/API would see an empty email
  // for every other client — breaking approval emails and any UI that
  // reads `record.email` for someone else's account.
  e.record.set("emailVisibility", true);

  e.next();
}, "users");

// Prevent a client from escalating their own role/status on update.
onRecordUpdateRequest((e) => {
  const auth = e.auth;
  const isAdmin = !!auth && auth.get("role") === "admin";

  if (!isAdmin) {
    const original = e.record.original();
    e.record.set("role", original.get("role"));
    e.record.set("status", original.get("status"));
    e.record.set("approvedAt", original.get("approvedAt"));
  }

  e.next();
}, "users");
