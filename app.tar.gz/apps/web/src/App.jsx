import React from 'react';
import { Route, Routes, BrowserRouter as Router } from 'react-router-dom';
import { Toaster } from '@/components/ui/sonner';
import ScrollToTop from '@/components/ScrollToTop.jsx';
import InstallPrompt from '@/components/InstallPrompt.jsx';
import { AuthProvider } from '@/hooks/useAuth.jsx';
import { LanguageProvider } from '@/i18n/LanguageContext.jsx';
import { isMaintenanceMode } from '@/utils/maintenanceMode.js';
import MaintenancePage from '@/pages/MaintenancePage.jsx';
import HomePage from '@/pages/HomePage.jsx';
import GuidesPage from '@/pages/GuidesPage.jsx';
import CryptoStakingPage from '@/pages/guides/CryptoStakingPage.jsx';
import ProofOfStakePage from '@/pages/guides/ProofOfStakePage.jsx';
import CarbonNeutralBlockchainsPage from '@/pages/guides/CarbonNeutralBlockchainsPage.jsx';
import AboutPage from '@/pages/AboutPage.jsx';
import ContactPage from '@/pages/ContactPage.jsx';
import PrivacyPolicyPage from '@/pages/PrivacyPolicyPage.jsx';
import WalletPage from '@/pages/WalletPage.jsx';
import SignUpPage from '@/pages/SignUpPage.jsx';
import LoginPage from '@/pages/LoginPage.jsx';
import AuthPage from '@/pages/AuthPage.jsx';
import AdminPage from '@/pages/AdminPage.jsx';
import VerifyEmailPage from '@/pages/VerifyEmailPage.jsx';
import ForgotPasswordPage from '@/pages/ForgotPasswordPage.jsx';
import ResetPasswordPage from '@/pages/ResetPasswordPage.jsx';
import InstallAppPage from '@/pages/InstallAppPage.jsx';

function App() {
  // Show maintenance page if maintenance mode is enabled
  if (isMaintenanceMode()) {
    return <MaintenancePage />;
  }

  return (
    <Router>
      <LanguageProvider>
      <AuthProvider>
        <ScrollToTop />
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/guides" element={<GuidesPage />} />
          <Route path="/guides/crypto-staking" element={<CryptoStakingPage />} />
          <Route path="/guides/proof-of-stake" element={<ProofOfStakePage />} />
          <Route path="/guides/carbon-neutral-blockchains" element={<CarbonNeutralBlockchainsPage />} />
          <Route path="/about" element={<AboutPage />} />
          <Route path="/contact" element={<ContactPage />} />
          <Route path="/privacy-policy" element={<PrivacyPolicyPage />} />
          <Route path="/wallet" element={<WalletPage />} />
          <Route path="/signup" element={<SignUpPage />} />
          <Route path="/login" element={<LoginPage />} />
          <Route path="/auth" element={<AuthPage />} />
          <Route path="/admin" element={<AdminPage />} />
          <Route path="/auth/confirm-verification" element={<VerifyEmailPage />} />
          <Route path="/auth/confirm-verification/:token" element={<VerifyEmailPage />} />
          <Route path="/forgot-password" element={<ForgotPasswordPage />} />
          <Route path="/reset-password/:token" element={<ResetPasswordPage />} />
          <Route path="/install-app" element={<InstallAppPage />} />
        </Routes>
        <Toaster />
        <InstallPrompt />
      </AuthProvider>
      </LanguageProvider>
    </Router>
  );
}

export default App;
