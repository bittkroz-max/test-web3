import React from 'react';
import { Helmet } from 'react-helmet';
import { Mail, MessageSquare, HelpCircle, Clock, Calendar, Star } from 'lucide-react';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import { useLanguage } from '@/i18n/LanguageContext.jsx';

const ContactPage = () => {
  const { t } = useLanguage();
  return <>
      <Helmet>
        <title>{t('Kontakt aufnehmen - delfinitx', 'Get in Touch - Contact delfinitx')}</title>
        <meta name="description" content={t('Kontaktieren Sie das delfinitx-Team. Fragen zu unserer WebSocket-API-Integration, Marktdaten oder Krypto-Handelsplattform? Wir helfen gerne.', 'Contact the delfinitx team. Questions about our WebSocket API integration, market data, or cryptocurrency trading platform? We\'re here to help.')} />
      </Helmet>

      <div className="min-h-screen flex flex-col">
        <Header />

        <main className="flex-1 py-12">
          <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center md:text-left mb-12">
              <h1 className="text-3xl md:text-4xl font-bold mb-4" style={{
                letterSpacing: '-0.02em'
              }}>
                {t('Kontakt aufnehmen', 'Get in touch')}
              </h1>
              <p className="text-lg leading-relaxed max-w-2xl text-muted-foreground">
                {t('Fragen zu unserer Plattform, Integration oder Krypto-Handelswerkzeugen? Wir freuen uns, von Ihnen zu hören.', 'Questions about our platform, integration, or crypto trading tools? We\'d love to hear from you.')}
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-16">
              <div className="bg-card rounded-xl p-6 text-center border border-border hover:border-primary/30 transition-colors duration-300">
                <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mx-auto mb-4">
                  <Mail className="w-6 h-6 text-primary" />
                </div>
                <h3 className="text-lg font-semibold mb-2">{t('E-Mail an uns', 'Email us')}</h3>
                <a href="mailto:support@delfinitx.com" className="text-sm text-muted-foreground hover:text-primary transition-colors duration-200">
                  support@delfinitx.com
                </a>
              </div>

              <div className="bg-card rounded-xl p-6 text-center border border-border hover:border-primary/30 transition-colors duration-300">
                <div className="w-12 h-12 rounded-xl bg-secondary/10 flex items-center justify-center mx-auto mb-4">
                  <MessageSquare className="w-6 h-6 text-secondary" />
                </div>
                <h3 className="text-lg font-semibold mb-2">{t('Live-Chat', 'Live chat')}</h3>
                <p className="text-sm text-muted-foreground">{t('Verfügbar Montag bis Freitag, 9–17 Uhr EST', 'Available Monday to Friday, 9am-5pm EST')}</p>
              </div>

              <div className="bg-card rounded-xl p-6 text-center border border-border hover:border-primary/30 transition-colors duration-300">
                <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center mx-auto mb-4">
                  <HelpCircle className="w-6 h-6 text-primary" />
                </div>
                <h3 className="text-lg font-semibold mb-2">FAQ</h3>
                <p className="text-sm text-muted-foreground">{t('Antworten auf häufige Fragen finden', 'Find answers to common questions')}</p>
              </div>
            </div>

            <div className="mb-12">
              <h2 className="text-2xl font-bold mb-8">{t('Informationen zur Antwortzeit', 'Response Time Information')}</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">

                {/* Response Time Card */}
                <div className="bg-card rounded-xl p-6 border border-border hover:border-primary/50 hover:shadow-md transition-all duration-300 flex items-start gap-5 group">
                  <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center shrink-0 group-hover:scale-110 transition-transform duration-300">
                    <Clock className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold mb-1">{t('Antwortzeit', 'Response Time')}</h3>
                    <p className="text-muted-foreground">30–45 {t('Min', 'Min')}</p>
                  </div>
                </div>

                {/* Support Hours Card */}
                <div className="bg-card rounded-xl p-6 border border-border hover:border-primary/50 hover:shadow-md transition-all duration-300 flex items-start gap-5 group">
                  <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center shrink-0 group-hover:scale-110 transition-transform duration-300">
                    <Calendar className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold mb-1">{t('Support-Zeiten', 'Support Hours')}</h3>
                    <p className="text-muted-foreground">{t('Montag–Freitag, 9:00–18:00 Uhr', 'Monday-Friday, 9:00 AM - 6:00 PM')}</p>
                  </div>
                </div>

                {/* Contact Channels Card */}
                <div className="bg-card rounded-xl p-6 border border-border hover:border-primary/50 hover:shadow-md transition-all duration-300 flex items-start gap-5 group">
                  <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center shrink-0 group-hover:scale-110 transition-transform duration-300">
                    <MessageSquare className="w-6 h-6 text-primary" />
                  </div>
                  <div className="w-full">
                    <h3 className="text-lg font-semibold mb-3">{t('Kontaktkanäle', 'Contact Channels')}</h3>
                    <ul className="space-y-3 text-muted-foreground">
                      <li className="flex items-center gap-3">
                        <MessageSquare className="w-4 h-4 text-primary/70" />
                        <span>{t('Live-Chat', 'Live Chat')}</span>
                      </li>
                    </ul>
                  </div>
                </div>

                {/* Priority Support Card */}
                <div className="bg-card rounded-xl p-6 border border-border hover:border-primary/50 hover:shadow-md transition-all duration-300 flex items-start gap-5 group">
                  <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center shrink-0 group-hover:scale-110 transition-transform duration-300">
                    <Star className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold mb-2">{t('Priority-Support', 'Priority Support')}</h3>
                    <p className="text-muted-foreground leading-relaxed">
                      {t('Beschleunigte Bearbeitung von Priority-Anfragen ist für Premium- und Institutionskonten verfügbar.', 'Expedited priority request handling is available for premium and institutional accounts.')}
                    </p>
                  </div>
                </div>

              </div>
            </div>
          </div>
        </main>

        <Footer />
      </div>
    </>;
};
export default ContactPage;
