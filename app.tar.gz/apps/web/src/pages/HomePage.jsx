import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowRight, TrendingUp, Shield, Zap, Activity, CreditCard, BarChart3, Wallet, Coins } from 'lucide-react';
import { Button } from '@/components/ui/button';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import TradingViewWidget from '@/components/TradingViewWidget.jsx';
import TickerBar from '@/components/TickerBar.jsx';
import TrendingAssets from '@/components/TrendingAssets.jsx';
import GuideCard from '@/components/GuideCard.jsx';
import AppDownloadSection from '@/components/AppDownloadSection.jsx';
import StakingSection1 from '@/components/StakingSection1.jsx';
import StakingSection2 from '@/components/StakingSection2.jsx';
import StakingSection3 from '@/components/StakingSection3.jsx';
import StakingSection4 from '@/components/StakingSection4.jsx';
import WhyChooseEcoCrypto from '@/components/WhyChooseEcoCrypto.jsx';
import { useLanguage } from '@/i18n/LanguageContext.jsx';

const HomePage = () => {
  const { t } = useLanguage();

  const featuredGuides = [{
    id: 1,
    slug: 'crypto-staking',
    title: t('Was ist Crypto Staking', 'What is Crypto Staking'),
    description: t('Verstehen Sie, wie Staking passive Belohnungen durch die Sicherung von Blockchain-Netzwerken ermöglicht und warum es zu einem Grundpfeiler modernen, nachhaltigen Investierens geworden ist.', 'Understand how staking lets you earn passive rewards by securing blockchain networks, and why it has become a cornerstone of modern sustainable investing.'),
    category: t('Anfänger', 'Beginners'),
    difficulty: t('Einfach', 'Easy'),
    readingTime: 8,
    date: t('15. April 2026', 'April 15, 2026')
  }, {
    id: 2,
    slug: 'proof-of-stake',
    title: t('Proof of Stake erklärt', 'Proof of Stake Explained'),
    description: t('Ein tiefer Einblick in den Konsensmechanismus, der den Energieverbrauch um bis zu 99 % gegenüber herkömmlichem Mining senkt, ohne die Netzwerksicherheit zu beeinträchtigen.', 'A deep dive into the consensus mechanism that reduces energy consumption by up to 99% compared to traditional mining, without compromising network security.'),
    category: t('Blockchain', 'Blockchain'),
    difficulty: t('Mittel', 'Medium'),
    readingTime: 12,
    date: t('12. April 2026', 'April 12, 2026')
  }, {
    id: 3,
    slug: 'carbon-neutral-blockchains',
    title: t('Kohlenstoffneutrale Blockchains', 'Carbon-Neutral Blockchains'),
    description: t('Sehen Sie, wie führende Blockchain-Netzwerke ihren ökologischen Fußabdruck durch geprüfte Partnerschaften mit erneuerbaren Energien und CO₂-Zertifikate ausgleichen.', 'See how leading blockchain networks offset their environmental footprint through verified renewable energy partnerships and carbon credit programs.'),
    category: t('Nachhaltigkeit', 'Sustainability'),
    difficulty: t('Einfach', 'Easy'),
    readingTime: 10,
    date: t('10. April 2026', 'April 10, 2026')
  }];

  const services = [{
    icon: CreditCard,
    title: t('Zahlungen', 'Payments'),
    description: t('Schnelle und globale Stablecoin-Zahlungen mit einer einzigen Integration', 'Fast and global stablecoin payments with a single integration'),
    color: 'primary'
  }, {
    icon: BarChart3,
    title: t('Handel', 'Trading'),
    description: t('Starten Sie Krypto-Handel und Verwahrung für Ihre Nutzer', 'Launch crypto trading and custody for your users'),
    color: 'secondary'
  }, {
    icon: Wallet,
    title: t('Wallets', 'Wallets'),
    description: t('Stellen Sie anpassbare und skalierbare Wallets für Ihr Unternehmen bereit', 'Deploy customizable and scalable wallets for your business'),
    color: 'crypto-blue'
  }, {
    icon: Coins,
    title: t('Stablecoins', 'Stablecoins'),
    description: t('Stabile, sichere und skalierbare digitale Währung', 'Stable, secure, and scalable digital currency'),
    color: 'crypto-purple'
  }];

  return <>
      <Helmet>
        <title>{t('delfinitx - Krypto-Handelsplattform', 'delfinitx - Crypto Trading Platform')}</title>
        <meta name="description" content={t('Professionelle Krypto-Handelsplattform mit Echtzeit-WebSocket-Daten von Binance. Live-Kurse, fortschrittliche Analysen und umfassende Markteinblicke für moderne Trader.', 'Professional cryptocurrency trading platform with real-time WebSocket data from Binance. Live prices, advanced analytics, and comprehensive market insights for modern traders.')} />
      </Helmet>

      <div className="min-h-screen flex flex-col">
        <Header />

        <section className="relative min-h-[90vh] flex items-center justify-center overflow-hidden">
          <div className="absolute inset-0 z-0" style={{
          backgroundImage: 'url(https://images.unsplash.com/photo-1641437741702-d55bfdc80063)',
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }}>
            <div className="absolute inset-0 bg-background/90" />
          </div>

          <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 text-center">
            <motion.div initial={{
            opacity: 0,
            y: 20
          }} animate={{
            opacity: 1,
            y: 0
          }} transition={{
            duration: 0.6
          }}>
              <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-6">
                <Activity className="w-4 h-4 text-primary" />
                <span className="text-sm font-medium text-primary">{t('Live-Daten, detailliert und fortschritten', 'Live data, detailed and advanced')}</span>
              </div>
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight mb-6" style={{
              letterSpacing: '-0.02em'
            }}>
                {t('Professioneller Krypto-Handel', 'Professional crypto trading')}{' '}
                <span className="text-primary">{t('angetrieben durch Echtzeitdaten', 'powered by real-time data')}</span>
              </h1>
              <p className="text-lg md:text-xl leading-relaxed max-w-2xl mx-auto mb-8">
                {t('Überwachen Sie Live-Kurse, Markttrends und fortschrittliche Analysen für professionelle Handelsentscheidungen.', 'Monitor live prices, market trends, and advanced analytics for professional trading decisions.')}
              </p>
              <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                <Button asChild size="lg" className="gap-2 transition-all duration-200 active:scale-[0.98]">
                  <Link to="/guides">
                    {t('Leitfäden entdecken', 'Explore Guides')}
                    <ArrowRight className="w-5 h-5" />
                  </Link>
                </Button>
                <Button asChild variant="outline" size="lg" className="transition-all duration-200 active:scale-[0.98]">
                  <Link to="/about">{t('Mehr erfahren', 'Learn More')}</Link>
                </Button>
              </div>
            </motion.div>
          </div>
        </section>

        <TickerBar />

        <AppDownloadSection />

        <section className="py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold mb-4" style={{
              letterSpacing: '-0.02em'
            }}>
                {t('Unsere Leistungen', 'Our Services')}
              </h2>
              <p className="text-lg leading-relaxed max-w-2xl mx-auto">
                {t('Umfassende Krypto-Lösungen für Privatpersonen und Unternehmen', 'Comprehensive crypto solutions for individuals and businesses')}
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {services.map((service, index) => {
              const Icon = service.icon;
              return <motion.div key={service.title} initial={{
                opacity: 0,
                y: 20
              }} whileInView={{
                opacity: 1,
                y: 0
              }} transition={{
                duration: 0.5,
                delay: index * 0.1
              }} viewport={{
                once: true
              }} whileHover={{
                scale: 1.05
              }} className="bg-card rounded-xl p-6 border border-border transition-all duration-300 hover:shadow-2xl hover:border-primary/30 cursor-pointer">
                    <div className={`w-12 h-12 rounded-lg bg-${service.color}/10 flex items-center justify-center mb-4`}>
                      <Icon className={`w-6 h-6 text-${service.color}`} style={{
                    color: `hsl(var(--${service.color}))`
                  }} />
                    </div>
                    <h3 className="text-xl font-bold mb-2">{service.title}</h3>
                    <p className="text-sm leading-relaxed">
                      {service.description}
                    </p>
                  </motion.div>;
            })}
            </div>
          </div>
        </section>

        <section className="py-24 bg-gradient-to-br from-secondary/10 to-background border-y border-border">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <motion.div initial={{
            opacity: 0,
            y: 20
          }} whileInView={{
            opacity: 1,
            y: 0
          }} transition={{
            duration: 0.6
          }} viewport={{
            once: true
          }}>
              <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-6" style={{
              letterSpacing: '-0.02em'
            }}>
                {t('Handeln Sie mit Vertrauen auf einer professionellen Plattform', 'Trade crypto with confidence on a professional platform')}
              </h2>
              <p className="text-lg md:text-xl leading-relaxed max-w-2xl mx-auto">
                {t('Fortschrittliche Handelswerkzeuge, Echtzeit-Marktdaten und Sicherheit auf Unternehmensebene für professionelle Trader.', 'Advanced trading tools, real-time market data, and enterprise-grade security for professional traders.')}
              </p>
            </motion.div>
          </div>
        </section>

        <section className="py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <motion.div initial={{
              opacity: 0,
              x: -20
            }} whileInView={{
              opacity: 1,
              x: 0
            }} transition={{
              duration: 0.6
            }} viewport={{
              once: true
            }} className="order-2 lg:order-1">
                <img src="https://horizons-cdn.hostinger.com/203fccdc-e8bc-431c-9992-1395201ebaa1/eb8e5a6952bd0c4fdff8f2ed87bd6823.png" alt={t('Vier Feature-Karten mit fortschrittlichen Handelswerkzeugen', 'Four feature cards showing advanced trading tools')} className="w-full h-auto rounded-2xl" />
              </motion.div>

              <motion.div initial={{
              opacity: 0,
              x: 20
            }} whileInView={{
              opacity: 1,
              x: 0
            }} transition={{
              duration: 0.6,
              delay: 0.2
            }} viewport={{
              once: true
            }} className="order-1 lg:order-2">
                <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-6" style={{
                letterSpacing: '-0.02em'
              }}>
                  {t('Leistungsstarke Werkzeuge, für den fortschrittlichen Trader', 'Powerful tools, designed for the advanced trader')}
                </h2>
                <p className="text-lg leading-relaxed mb-8 max-w-prose">
                  {t('Professionelle Analysetools mit Sicherheit auf Unternehmensebene bieten das ultimative Handelserlebnis. Zugriff auf anspruchsvolle Chart-Funktionen, Echtzeit-Orderbücher und tiefe Liquidität über hunderte von Märkten.', 'Professional analytical tools with enterprise-grade security deliver the ultimate trading experience. Access sophisticated charting capabilities, real-time order books, and deep liquidity across hundreds of markets.')}
                </p>
                <Button variant="outline" size="lg" className="gap-2 transition-all duration-200 active:scale-[0.98]">
                  {t('Mehr erfahren', 'Learn More')}
                  <ArrowRight className="w-5 h-5" />
                </Button>
              </motion.div>
            </div>
          </div>
        </section>

        <TrendingAssets />

        <TradingViewWidget />

        <section className="py-20 bg-muted border-y border-border">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <motion.div initial={{
              opacity: 0,
              x: -20
            }} whileInView={{
              opacity: 1,
              x: 0
            }} transition={{
              duration: 0.6
            }} viewport={{
              once: true
            }}>
                <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-6" style={{
                letterSpacing: '-0.02em'
              }}>
                  {t('Millionen von Token und Aktien entdecken – alles an einem Ort', 'Explore millions of tokens and stocks, all in one place')}
                </h2>
                <p className="text-lg leading-relaxed mb-8 max-w-prose">
                  {t('Ein vertrauenswürdiges Konto für den Handel mit allem – von Aktien bis Bitcoin.¹', 'One trusted account for trading everything—from stocks to Bitcoin.¹')}
                </p>
                <Button size="lg" className="gap-2 transition-all duration-200 active:scale-[0.98]">
                  {t('Jetzt handeln', 'Start Trading Now')}
                  <ArrowRight className="w-5 h-5" />
                </Button>
              </motion.div>

              <motion.div initial={{
              opacity: 0,
              x: 20
            }} whileInView={{
              opacity: 1,
              x: 0
            }} transition={{
              duration: 0.6,
              delay: 0.2
            }} viewport={{
              once: true
            }} className="relative">
                <img src="https://horizons-cdn.hostinger.com/203fccdc-e8bc-431c-9992-1395201ebaa1/f6dc8ee6b66c6e227b6fdf1cb48c0355.png" alt={t('3D-Krypto-Münzen mit Neon-Glühen', '3D crypto coins with neon glow')} className="w-full h-auto rounded-2xl" />
              </motion.div>
            </div>
          </div>
        </section>

        <section className="py-20 bg-muted border-y border-border">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div initial={{
            opacity: 0,
            y: 20
          }} whileInView={{
            opacity: 1,
            y: 0
          }} transition={{
            duration: 0.6
          }} viewport={{
            once: true
          }} className="text-center">
              <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-8" style={{
              letterSpacing: '-0.02em'
            }}>
                {t('Krypto über den Handel hinaus', 'Crypto beyond trading')}
              </h2>
              <div className="relative max-w-5xl mx-auto">
                <img src="https://horizons-cdn.hostinger.com/203fccdc-e8bc-431c-9992-1395201ebaa1/c30556a9b2943b685059bc062698fd54.png" alt={t('Karten für Universität, Sicherheit und Entwickler', 'University, Security, and Developers cards')} className="w-full h-auto rounded-2xl" />
              </div>
            </motion.div>
          </div>
        </section>

        <StakingSection1 />
        <StakingSection2 />
        <StakingSection3 />
        <StakingSection4 />

        <section className="py-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold mb-4" style={{
              letterSpacing: '-0.02em'
            }}>
                {t('Warum delfinitx wählen', 'Why choose delfinitx')}
              </h2>
              <p className="text-lg leading-relaxed max-w-2xl mx-auto">
                {t('Werkzeuge in professioneller Qualität für modernen Krypto-Handel', 'Professional-grade tools for modern crypto trading')}
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
              <motion.div initial={{
              opacity: 0,
              y: 20
            }} whileInView={{
              opacity: 1,
              y: 0
            }} transition={{
              duration: 0.5
            }} viewport={{
              once: true
            }} className="flex gap-4">
                <div className="flex-shrink-0">
                  <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
                    <Activity className="w-6 h-6 text-primary" />
                  </div>
                </div>
                <div>
                  <h3 className="text-xl font-semibold mb-2">{t('Echtzeit-WebSocket-Daten', 'Real-time WebSocket data')}</h3>
                  <p className="leading-relaxed">
                    {t('Sofortige Kursaktualisierungen mit automatischer Wiederverbindung', 'Instant price updates with automatic reconnection')}
                  </p>
                </div>
              </motion.div>

              <motion.div initial={{
              opacity: 0,
              y: 20
            }} whileInView={{
              opacity: 1,
              y: 0
            }} transition={{
              duration: 0.5,
              delay: 0.1
            }} viewport={{
              once: true
            }} className="flex gap-4">
                <div className="flex-shrink-0">
                  <div className="w-12 h-12 rounded-lg bg-secondary/10 flex items-center justify-center">
                    <Shield className="w-6 h-6 text-secondary" />
                  </div>
                </div>
                <div>
                  <h3 className="text-xl font-semibold mb-2">{t('Sicherheit auf Unternehmensebene', 'Enterprise security')}</h3>
                  <p className="leading-relaxed">
                    {t('Sicherheitsprotokolle auf Bankniveau und Verschlüsselung zum Schutz Ihrer Vermögenswerte und persönlichen Daten.', 'Bank-level security protocols and encryption to protect your assets and personal information.')}
                  </p>
                </div>
              </motion.div>

              <motion.div initial={{
              opacity: 0,
              y: 20
            }} whileInView={{
              opacity: 1,
              y: 0
            }} transition={{
              duration: 0.5,
              delay: 0.2
            }} viewport={{
              once: true
            }} className="flex gap-4">
                <div className="flex-shrink-0">
                  <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
                    <TrendingUp className="w-6 h-6 text-primary" />
                  </div>
                </div>
                <div>
                  <h3 className="text-xl font-semibold mb-2">{t('Fortschrittliche Marktwerkzeuge', 'Advanced market tools')}</h3>
                  <p className="leading-relaxed">
                    {t('Sortierbare Tabellen, Suchfilter und Kursänderungsindikatoren für umfassende Marktanalyse.', 'Sortable tables, search filters, and price change indicators for comprehensive market analysis.')}
                  </p>
                </div>
              </motion.div>

              <motion.div initial={{
              opacity: 0,
              y: 20
            }} whileInView={{
              opacity: 1,
              y: 0
            }} transition={{
              duration: 0.5,
              delay: 0.3
            }} viewport={{
              once: true
            }} className="flex gap-4">
                <div className="flex-shrink-0">
                  <div className="w-12 h-12 rounded-lg bg-secondary/10 flex items-center justify-center">
                    <Zap className="w-6 h-6 text-secondary" />
                  </div>
                </div>
                <div>
                  <h3 className="text-xl font-semibold mb-2">{t('Blitzschnelle Aktualisierungen', 'Lightning-fast updates')}</h3>
                  <p className="leading-relaxed">
                    {t('Kursaktualisierungen in unter einer Sekunde mit visuellen Indikatoren für Kursbewegungen und Trendwechsel.', 'Sub-second price updates with visual indicators for price movements and trend changes.')}
                  </p>
                </div>
              </motion.div>
            </div>
          </div>
        </section>

        <section className="py-20 bg-muted">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-end justify-between mb-12">
              <div>
                <h2 className="text-3xl md:text-4xl font-bold mb-4" style={{
                letterSpacing: '-0.02em'
              }}>
                  {t('Empfohlene Leitfäden', 'Featured Guides')}
                </h2>
                <p className="text-lg leading-relaxed">
                  {t('Erfahren Sie mehr über Krypto-Handel und Blockchain-Technologie', 'Learn about cryptocurrency trading and blockchain technology')}
                </p>
              </div>
              <Button asChild variant="outline" className="hidden md:inline-flex">
                <Link to="/guides">{t('Alle Leitfäden ansehen', 'View All Guides')}</Link>
              </Button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {featuredGuides.map((guide, index) => <GuideCard key={guide.id} guide={guide} index={index} />)}
            </div>

            <div className="mt-8 text-center md:hidden">
              <Button asChild variant="outline">
                <Link to="/guides">{t('Alle Leitfäden ansehen', 'View All Guides')}</Link>
              </Button>
            </div>
          </div>
        </section>

        <WhyChooseEcoCrypto />

        <Footer />
      </div>
    </>;
};
export default HomePage;
