import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Accordion, AccordionItem, AccordionTrigger, AccordionContent } from '@/components/ui/accordion';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import { useLanguage } from '@/i18n/LanguageContext.jsx';

const GuidesPage = () => {
  const { t } = useLanguage();

  const faqCategories = [
    {
      title: t('Registrierung & E-Mail-Verifizierung', 'Registration & Email Verification'),
      id: 'registration',
      questions: [
        {
          id: 'reg-1',
          question: t('Wie erstelle ich ein Konto bei delfinitx?', 'How do I create an account on delfinitx?'),
          answer: t('Die Kontoerstellung bei delfinitx ist einfach und unkompliziert. Besuchen Sie unsere Registrierungsseite, geben Sie Ihre E-Mail-Adresse ein und erstellen Sie ein sicheres Passwort. Innerhalb weniger Minuten erhalten Sie eine Verifizierungs-E-Mail. Klicken Sie auf den Verifizierungslink in der E-Mail, um Ihr Konto zu bestätigen. Nach der Verifizierung können Sie Ihre Identitätsprüfung (KYC) abschließen, um alle Handelsfunktionen freizuschalten.', 'Creating an account on delfinitx is simple and straightforward. Visit our Sign Up page, enter your email address and create a secure password. You\'ll receive a verification email within minutes. Click the verification link in the email to confirm your account. Once verified, you can proceed to complete your identity verification (KYC) to unlock full trading capabilities.')
        },
        {
          id: 'reg-2',
          question: t('Warum muss ich meine E-Mail-Adresse verifizieren?', 'Why do I need to verify my email address?'),
          answer: t('Die E-Mail-Verifizierung ist eine wichtige Sicherheitsmaßnahme, die sicherstellt, dass Sie Zugriff auf die mit Ihrem Konto verknüpfte E-Mail-Adresse haben. Dies schützt Ihr Konto vor unbefugtem Zugriff und ermöglicht es uns, wichtige Sicherheitsbenachrichtigungen, Transaktionsbestätigungen und Konto-Updates direkt an Sie zu senden. Es hilft uns auch, regulatorische Anforderungen für Finanzplattformen zu erfüllen.', 'Email verification is a critical security measure that ensures you have access to the email address associated with your account. This protects your account from unauthorized access and allows us to send important security notifications, transaction confirmations, and account updates directly to you. It also helps us comply with regulatory requirements for financial platforms.')
        },
        {
          id: 'reg-3',
          question: t('Wie lange dauert die E-Mail-Verifizierung?', 'How long does email verification take?'),
          answer: t('Die E-Mail-Verifizierung erfolgt in der Regel sofort. Sie sollten die Verifizierungs-E-Mail innerhalb von 1–2 Minuten nach der Registrierung erhalten. Wenn sie nicht in Ihrem Posteingang erscheint, prüfen Sie Ihren Spam- oder Junk-Ordner. Der Verifizierungslink bleibt 7 Tage gültig, sodass Sie ausreichend Zeit haben, den Vorgang abzuschließen. Wenn Ihr Link abgelaufen ist, können Sie eine neue Verifizierungs-E-Mail aus Ihren Kontoeinstellungen anfordern.', 'Email verification is typically instant. You should receive the verification email within 1-2 minutes of signing up. If you don\'t see it in your inbox, check your spam or junk folder. The verification link remains valid for 7 days, giving you plenty of time to complete the process. If your link expires, you can request a new verification email from your account settings.')
        },
        {
          id: 'reg-4',
          question: t('Kann ich meine E-Mail-Adresse nach der Registrierung ändern?', 'Can I change my email address after registration?'),
          answer: t('Ja, Sie können Ihre E-Mail-Adresse in Ihren Kontoeinstellungen aktualisieren. Sie müssen jedoch die neue E-Mail-Adresse verifizieren, bevor die Änderung wirksam wird. Aus Sicherheitsgründen senden wir einen Bestätigungslink an sowohl Ihre alte als auch Ihre neue E-Mail-Adresse. So wird sichergestellt, dass nur Sie die E-Mail-Änderung autorisieren können und Ihr Konto vor unbefugten Änderungen geschützt ist.', 'Yes, you can update your email address in your account settings. However, you\'ll need to verify the new email address before the change takes effect. For security reasons, we\'ll send a confirmation link to both your old and new email addresses. This ensures that only you can authorize the email change and protects your account from unauthorized modifications.')
        },
        {
          id: 'reg-5',
          question: t('Was soll ich tun, wenn ich die Verifizierungs-E-Mail nicht erhalte?', 'What should I do if I don\'t receive the verification email?'),
          answer: t('Prüfen Sie zuerst Ihren Spam-, Junk- oder Werbe-Ordner – Verifizierungs-E-Mails werden manchmal herausgefiltert. Wenn Sie sie immer noch nicht finden, stellen Sie sicher, dass Sie bei der Registrierung die richtige E-Mail-Adresse eingegeben haben. Sie können über die Anmeldeseite eine neue Verifizierungs-E-Mail anfordern, indem Sie auf „Verifizierungs-E-Mail erneut senden" klicken. Bei anhaltenden Problemen wenden Sie sich an unser Support-Team unter support@delfinitx.com.', 'First, check your spam, junk, or promotions folder—verification emails sometimes get filtered. If you still can\'t find it, ensure you entered the correct email address during signup. You can request a new verification email from the login page by clicking "Resend Verification Email." If you continue to experience issues, contact our support team at support@delfinitx.com for assistance.')
        },
        {
          id: 'reg-6',
          question: t('Ist mein Passwort bei delfinitx sicher?', 'Is my password secure on delfinitx?'),
          answer: t('Ja, wir nehmen Passwortsicherheit sehr ernst. Ihr Passwort wird mit branchenüblichen Verschlüsselungsprotokollen verschlüsselt und niemals im Klartext gespeichert. Wir empfehlen die Verwendung eines starken, einzigartigen Passworts mit einer Mischung aus Groß- und Kleinbuchstaben, Zahlen und Sonderzeichen. Teilen Sie Ihr Passwort niemals mit jemandem und ziehen Sie die Nutzung eines Passwort-Managers in Betracht, um Ihre Zugangsdaten zu schützen.', 'Yes, we take password security very seriously. Your password is encrypted using industry-standard encryption protocols and is never stored in plain text. We recommend using a strong, unique password with a mix of uppercase and lowercase letters, numbers, and special characters. Never share your password with anyone, and consider using a password manager to keep your credentials secure.')
        }
      ]
    },
    {
      title: t('KYC & Identitätsverifizierung', 'KYC & Identity Verification'),
      id: 'kyc',
      questions: [
        {
          id: 'kyc-1',
          question: t('Was ist KYC und warum ist es erforderlich?', 'What is KYC and why is it required?'),
          answer: t('KYC steht für „Know Your Customer" (Kenne deinen Kunden). Es ist eine regulatorische Anforderung, die Betrug, Geldwäsche und Terrorismusfinanzierung verhindern soll. Durch die Verifizierung Ihrer Identität stellen wir sicher, dass delfinitx weltweit im Einklang mit Finanzvorschriften arbeitet. Die KYC-Verifizierung schützt auch Ihr Konto und ermöglicht es uns, Ihnen die volle Palette der Handels- und Finanzdienstleistungen auf unserer Plattform zur Verfügung zu stellen.', 'KYC stands for "Know Your Customer." It\'s a regulatory requirement that helps prevent fraud, money laundering, and terrorist financing. By verifying your identity, we ensure that delfinitx operates in compliance with financial regulations worldwide. KYC verification also protects your account and enables us to provide you with the full range of trading and financial services available on our platform.')
        },
        {
          id: 'kyc-2',
          question: t('Welche Dokumente benötige ich für die Identitätsverifizierung?', 'What documents do I need for identity verification?'),
          answer: t('Wir akzeptieren drei Arten von amtlichen Lichtbildausweisen: einen gültigen Reisepass, Führerschein oder Personalausweis. Das Dokument muss aktuell (nicht abgelaufen) sein und deutlich Ihren vollständigen Namen, Ihr Geburtsdatum und Ihr Foto zeigen. Stellen Sie sicher, dass das Dokument gut beleuchtet ist und der gesamte Text lesbar ist. Wir akzeptieren Dokumente aus den meisten Ländern weltweit, obwohl einige Regionen spezifische Anforderungen haben können.', 'We accept three types of government-issued photo identification: a valid Passport, Driver\'s License, or National ID Card. The document must be current (not expired) and clearly show your full name, date of birth, and photograph. Ensure the document is well-lit and all text is legible. We accept documents from most countries worldwide, though some regions may have specific requirements.')
        },
        {
          id: 'kyc-3',
          question: t('Wie lange dauert die KYC-Verifizierung?', 'How long does KYC verification take?'),
          answer: t('Die meisten KYC-Verifizierungen werden innerhalb von 24–48 Stunden abgeschlossen. Unser Compliance-Team prüft Ihre Dokumente, um sicherzustellen, dass sie unseren Anforderungen entsprechen. Sie erhalten eine E-Mail-Benachrichtigung, sobald Ihre Verifizierung genehmigt wurde oder wir weitere Informationen benötigen. In einigen Fällen kann die Verifizierung länger dauern, wenn Dokumente unklar sind oder zusätzliche Prüfungen erforderlich sind. Sie können Ihren Verifizierungsstatus jederzeit in Ihren Kontoeinstellungen einsehen.', 'Most KYC verifications are completed within 24-48 hours. Our compliance team reviews your documents to ensure they meet our requirements. You\'ll receive an email notification once your verification is approved or if we need additional information. In some cases, verification may take longer if documents are unclear or if additional checks are required. You can check your verification status anytime in your account settings.')
        },
        {
          id: 'kyc-4',
          question: t('Was passiert, wenn meine KYC-Verifizierung abgelehnt wird?', 'What happens if my KYC verification is rejected?'),
          answer: t('Wenn Ihre Verifizierung abgelehnt wird, senden wir Ihnen eine E-Mail mit der Erklärung des Grundes. Häufige Gründe sind unklare Dokumentbilder, abgelaufene Dokumente oder Informationsabweichungen. Sie können Ihre Dokumente mit Korrekturen erneut einreichen. Stellen Sie sicher, dass Ihr Dokument gut beleuchtet ist, der gesamte Text deutlich sichtbar ist und Ihre Informationen genau mit den bei der Registrierung angegebenen übereinstimmen. Bei Fragen zur Ablehnung wenden Sie sich an support@delfinitx.com.', 'If your verification is rejected, we\'ll send you an email explaining the reason. Common reasons include unclear document images, expired documents, or information mismatches. You can resubmit your documents with corrections. Ensure your document is well-lit, all text is clearly visible, and your information matches exactly what you provided during registration. If you have questions about the rejection, contact support@delfinitx.com.')
        },
        {
          id: 'kyc-5',
          question: t('Sind meine persönlichen Daten während der KYC-Verifizierung sicher?', 'Is my personal information safe during KYC verification?'),
          answer: t('Absolut. Wir schützen Ihre persönlichen Daten mit Sicherheitsmaßnahmen auf Unternehmensebene, einschließlich Verschlüsselung und sicherer Datenspeicherung. Ihre Dokumente werden ausschließlich von unserem Compliance-Team bearbeitet und ohne Ihre Zustimmung niemals an Dritte weitergegeben. Wir halten die DSGVO und andere internationale Datenschutzvorschriften ein. Ihre Daten werden nur so lange aufbewahrt, wie für die regulatorische Compliance erforderlich, und danach sicher gelöscht.', 'Absolutely. We protect your personal information with enterprise-grade security measures, including encryption and secure data storage. Your documents are handled only by our compliance team and are never shared with third parties without your consent. We comply with GDPR and other international data protection regulations. Your information is retained only as long as necessary for regulatory compliance and is securely deleted afterward.')
        },
        {
          id: 'kyc-6',
          question: t('Kann ich handeln, bevor ich die KYC-Verifizierung abschließe?', 'Can I trade before completing KYC verification?'),
          answer: t('Nein, die KYC-Verifizierung ist erforderlich, bevor Sie auf Handelsfunktionen bei delfinitx zugreifen können. Dies ist eine regulatorische Anforderung, die für alle Nutzer gilt. Sie können jedoch unsere Bildungsressourcen, Leitfäden und Marktdaten erkunden, während Ihre Verifizierung aussteht. Sobald Ihr KYC genehmigt ist, erhalten Sie sofortigen Zugriff auf alle Handelsfunktionen und können mit dem Kauf und Verkauf von Kryptowährungen beginnen.', 'No, KYC verification is required before you can access trading features on delfinitx. This is a regulatory requirement that applies to all users. However, you can explore our educational resources, guides, and market data while your verification is pending. Once your KYC is approved, you\'ll immediately gain access to all trading features and can start buying and selling cryptocurrencies.')
        }
      ]
    },
    {
      title: t('Sicherheit & Zertifizierungen', 'Security & Certifications'),
      id: 'security',
      questions: [
        {
          id: 'sec-1',
          question: t('Welche Sicherheitszertifizierungen besitzt delfinitx?', 'What security certifications does delfinitx hold?'),
          answer: t('delfinitx ist auf SOC-2-Type-II- und ISO-27001-Compliance geprüft und zertifiziert. Die SOC-2-Type-II-Zertifizierung belegt, dass wir robuste Kontrollen über Sicherheit, Verfügbarkeit und Vertraulichkeit unserer Systeme aufrechterhalten. ISO 27001 ist ein internationaler Standard für Informations Sicherheitsmanagement. Diese Zertifizierungen sind der Goldstandard für Sicherheitscompliance in der Finanztechnologie-Branche und werden regelmäßig von unabhängigen Dritten geprüft.', 'delfinitx is audited and certified for SOC 2 Type II and ISO 27001 compliance. SOC 2 Type II certification demonstrates that we maintain robust controls over security, availability, and confidentiality of our systems. ISO 27001 is an international standard for information security management. These certifications are the gold standards for security compliance in the financial technology industry and are regularly audited by independent third parties.')
        },
        {
          id: 'sec-2',
          question: t('Wie schützt delfinitx mein Konto vor unbefugtem Zugriff?', 'How does delfinitx protect my account from unauthorized access?'),
          answer: t('Wir setzen mehrere Sicherheitsebenen ein, um Ihr Konto zu schützen. Ihr Passwort wird mit branchenüblichen Protokollen verschlüsselt, und wir überwachen auf verdächtige Anmeldeversuche. Wir empfehlen die Aktivierung zusätzlicher Sicherheitsfunktionen wie starker Passwörter und die Sicherung Ihrer E-Mail. Unsere Systeme nutzen fortschrittliche Betrugserkennung, um unbefugten Zugriff zu erkennen und zu verhindern. Bei verdächtigen Aktivitäten benachrichtigen wir Sie sofort und fordern möglicherweise eine zusätzliche Verifizierung an.', 'We employ multiple layers of security to protect your account. Your password is encrypted using industry-standard protocols, and we monitor for suspicious login attempts. We recommend enabling additional security features such as strong passwords and keeping your email secure. Our systems use advanced fraud detection to identify and prevent unauthorized access. If we detect suspicious activity, we\'ll notify you immediately and may require additional verification.')
        },
        {
          id: 'sec-3',
          question: t('Ist meine Kryptowährung bei delfinitx sicher?', 'Is my cryptocurrency secure on delfinitx?'),
          answer: t('Ja, Ihre Krypto-Bestände sind durch Sicherheitsinfrastruktur auf Unternehmensebene geschützt. Wir verwenden Cold Storage für die Mehrheit der Kundenvermögenswerte, das bedeutet, sie werden offline aufbewahrt und vor Online-Bedrohungen geschützt. Unsere Hot Wallets (für aktiven Handel) sind mit Multi-Signatur-Technologie gesichert und werden rund um die Uhr überwacht. Alle Transaktionen werden verschlüsselt und auf der Blockchain für Transparenz und Unveränderlichkeit aufgezeichnet.', 'Yes, your cryptocurrency holdings are protected by enterprise-grade security infrastructure. We use cold storage for the majority of customer assets, which means they are kept offline and protected from online threats. Our hot wallets (used for active trading) are secured with multi-signature technology and are monitored 24/7. All transactions are encrypted and recorded on the blockchain for transparency and immutability.')
        },
        {
          id: 'sec-4',
          question: t('Welche Verschlüsselung verwendet delfinitx?', 'What encryption does delfinitx use?'),
          answer: t('delfinitx verwendet branchenübliche Verschlüsselungsprotokolle, um alle Daten bei der Übertragung und im Ruhezustand zu schützen. Wir setzen TLS-1.2+-Verschlüsselung für die gesamte Kommunikation zwischen Ihrem Browser und unseren Servern ein, sodass sensible Informationen wie Passwörter und Transaktionsdetails geschützt sind. Alle gespeicherten Daten werden mit AES-256-Verschlüsselung verschlüsselt, demselben Standard, der von Regierungen und Finanzinstituten weltweit verwendet wird.', 'delfinitx uses industry-standard encryption protocols to protect all data in transit and at rest. We employ TLS 1.2+ encryption for all communications between your browser and our servers, ensuring that sensitive information like passwords and transaction details are protected. All stored data is encrypted using AES-256 encryption, which is the same standard used by governments and financial institutions worldwide.')
        },
        {
          id: 'sec-5',
          question: t('Was soll ich tun, wenn ich vermute, dass mein Konto kompromittiert wurde?', 'What should I do if I suspect my account has been compromised?'),
          answer: t('Wenn Sie unbefugten Zugriff auf Ihr Konto vermuten, ändern Sie sofort Ihr Passwort und wenden Sie sich an unser Support-Team unter support@delfinitx.com. Zögern Sie nicht – je schneller Sie handeln, desto besser können wir Ihre Vermögenswerte schützen. Unser Sicherheitsteam wird den Vorfall untersuchen und geeignete Maßnahmen ergreifen, um Ihr Konto zu sichern. Wir empfehlen die Aktivierung zusätzlicher Sicherheitsfunktionen und die regelmäßige Überprüfung Ihrer Kontoaktivität auf verdächtige Transaktionen.', 'If you suspect unauthorized access to your account, immediately change your password and contact our support team at support@delfinitx.com. Do not delay—the faster you act, the better we can protect your assets. Our security team will investigate the incident and take appropriate measures to secure your account. We recommend enabling additional security features and monitoring your account activity regularly for any suspicious transactions.')
        },
        {
          id: 'sec-6',
          question: t('Hält delfinitx Datenschutzvorschriften ein?', 'Does delfinitx comply with data protection regulations?'),
          answer: t('Ja, delfinitx hält die DSGVO (Datenschutz-Grundverordnung) und andere internationale Datenschutzgesetze vollständig ein. Wir erheben nur die personenbezogenen Daten, die zur Erbringung unserer Dienste und zur Einhaltung regulatorischer Anforderungen erforderlich sind. Sie haben jederzeit das Recht, auf Ihre personenbezogenen Daten zuzugreifen, diese zu ändern oder zu löschen. Weitere Details zur Verarbeitung Ihrer Daten finden Sie in unserer Datenschutzrichtlinie. Bei Fragen zum Datenschutz wenden Sie sich an support@delfinitx.com.', 'Yes, delfinitx fully complies with GDPR (General Data Protection Regulation) and other international data protection laws. We collect only the personal information necessary to provide our services and comply with regulatory requirements. You have the right to access, modify, or delete your personal data at any time. For more details on how we handle your information, please review our Privacy Policy. If you have questions about data protection, contact support@delfinitx.com.')
        }
      ]
    }
  ];

  return (
    <>
      <Helmet>
        <title>{t('Leitfäden & FAQ - delfinitx', 'Guides & FAQ - delfinitx')}</title>
        <meta
          name="description"
          content={t('Umfassende Leitfäden und häufig gestellte Fragen zu delfinitx-Registrierung, KYC-Verifizierung, Sicherheit und Zertifizierungen.', 'Comprehensive guides and frequently asked questions about delfinitx registration, KYC verification, security, and certifications.')}
        />
      </Helmet>

      <div className="min-h-screen flex flex-col">
        <Header />

        <main className="flex-1">
          {/* Hero Section */}
          <section className="relative min-h-[50vh] flex items-center justify-center overflow-hidden py-20">
            <div className="absolute inset-0 z-0" style={{
              backgroundImage: 'url(https://images.unsplash.com/photo-1641437741702-d55bfdc80063)',
              backgroundSize: 'cover',
              backgroundPosition: 'center'
            }}>
              <div className="absolute inset-0 bg-background/90" />
            </div>

            <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
              >
                <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight mb-6" style={{ letterSpacing: '-0.02em' }}>
                  {t('Leitfäden & FAQ', 'Guides & FAQ')}
                </h1>
                <p className="text-lg md:text-xl leading-relaxed max-w-2xl mx-auto">
                  {t('Antworten auf häufige Fragen zu Registrierung, Identitätsverifizierung, Sicherheit und mehr.', 'Find answers to common questions about registration, identity verification, security, and more.')}
                </p>
              </motion.div>
            </div>
          </section>

          {/* FAQ Content */}
          <section className="py-20 flex-grow">
            <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
              {faqCategories.map((category, categoryIndex) => (
                <motion.div
                  key={category.id}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: categoryIndex * 0.1 }}
                  viewport={{ once: true }}
                  className="mb-16"
                >
                  {/* Category Title */}
                  <div className="mb-8">
                    <h2 className="text-3xl md:text-4xl font-bold mb-2" style={{ letterSpacing: '-0.02em' }}>
                      {category.title}
                    </h2>
                    <div className="h-1 w-16 bg-primary rounded-full" />
                  </div>

                  {/* Accordion */}
                  <Accordion type="single" collapsible className="space-y-4">
                    {category.questions.map((item, questionIndex) => (
                      <motion.div
                        key={item.id}
                        initial={{ opacity: 0, y: 10 }}
                        whileInView={{ opacity: 1, y: 0 }}
                        transition={{ duration: 0.4, delay: questionIndex * 0.05 }}
                        viewport={{ once: true }}
                      >
                        <AccordionItem
                          value={item.id}
                          className="border border-border rounded-lg overflow-hidden bg-card hover:border-primary/30 transition-all duration-300"
                        >
                          <AccordionTrigger className="px-6 py-4 hover:bg-muted/50 transition-colors duration-200 text-left">
                            <span className="text-lg font-semibold text-foreground">
                              {item.question}
                            </span>
                          </AccordionTrigger>
                          <AccordionContent className="px-6 py-4 bg-muted/30 border-t border-border">
                            <p className="text-base leading-relaxed text-foreground/90">
                              {item.answer}
                            </p>
                          </AccordionContent>
                        </AccordionItem>
                      </motion.div>
                    ))}
                  </Accordion>
                </motion.div>
              ))}

              {/* Contact Section */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
                viewport={{ once: true }}
                className="mt-20 p-8 rounded-lg bg-primary/5 border border-primary/20"
              >
                <h3 className="text-2xl font-bold mb-4">{t('Ihre Antwort nicht gefunden?', 'Didn\'t find your answer?')}</h3>
                <p className="text-lg leading-relaxed mb-6">
                  {t('Wenn Sie weitere Fragen haben oder Hilfe benötigen, steht Ihnen unser Support-Team gerne zur Verfügung. Kontaktieren Sie uns unter ', 'If you have additional questions or need further assistance, our support team is here to help. Contact us at ')}
                  <a href="mailto:support@delfinitx.com" className="text-primary font-semibold hover:underline">
                    support@delfinitx.com
                  </a>
                  {t(' und wir melden uns so schnell wie möglich bei Ihnen.', ' and we\'ll get back to you as soon as possible.')}
                </p>
              </motion.div>
            </div>
          </section>
        </main>

        <Footer />
      </div>
    </>
  );
};

export default GuidesPage;
