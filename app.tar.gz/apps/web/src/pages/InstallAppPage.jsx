import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { Download, Apple, Chrome, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { getInstallState, subscribeInstallPrompt, triggerInstallPrompt } from '@/lib/installPromptStore';
import { useLanguage } from '@/i18n/LanguageContext.jsx';

export default function InstallAppPage() {
  const { t } = useLanguage();
  const [deferredPrompt, setDeferredPrompt] = useState(() => getInstallState().deferredPrompt);
  const [isInstalled, setIsInstalled] = useState(() => getInstallState().isInstalled);
  const [showIOSInstructions, setShowIOSInstructions] = useState(false);
  const [isAndroid, setIsAndroid] = useState(false);
  const [isIOS, setIsIOS] = useState(false);

  useEffect(() => {
    const ua = navigator.userAgent.toLowerCase();
    const isAndroidDevice = /android/.test(ua);
    const isIOSDevice = /iphone|ipad|ipod/.test(ua);

    setIsAndroid(isAndroidDevice);
    setIsIOS(isIOSDevice);

    const { deferredPrompt: currentPrompt, isInstalled: currentInstalled } = getInstallState();
    setDeferredPrompt(currentPrompt);
    setIsInstalled(currentInstalled);

    const unsubscribe = subscribeInstallPrompt(({ deferredPrompt: nextPrompt, isInstalled: nextInstalled }) => {
      setDeferredPrompt(nextPrompt);
      setIsInstalled(nextInstalled);
    });

    return unsubscribe;
  }, []);

  const handleAndroidInstall = async () => {
    const choice = await triggerInstallPrompt();
    if (choice?.outcome === 'accepted') {
      setIsInstalled(true);
    }
    setDeferredPrompt(null);
  };

  const handleIOSInstall = () => {
    setShowIOSInstructions(true);
  };

  return (
    <>
      <Helmet>
        <title>{t('delfinitx App installieren', 'Install delfinitx App')}</title>
        <meta name="description" content={t('Installieren Sie die delfinitx PWA-App auf Ihrem Gerät', 'Install the delfinitx PWA app on your device')} />
        <meta name="robots" content="noindex, nofollow" />
      </Helmet>

      <div className="min-h-screen bg-gradient-to-br from-background via-background to-muted/30 flex items-center justify-center px-4 py-12">
        <div className="w-full max-w-md">
          {/* Header */}
          <div className="text-center mb-8">
            <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/10 mb-4">
              <Download className="w-8 h-8 text-primary" strokeWidth={1.5} />
            </div>
            <h1 className="text-3xl font-bold text-foreground mb-2">{t('delfinitx installieren', 'Install delfinitx')}</h1>
            <p className="text-muted-foreground">{t('Holen Sie sich die App für schnellen Zugriff auf Ihr Gerät', 'Get the app on your device for quick access')}</p>
          </div>

          {/* Status Card */}
          {isInstalled && (
            <div className="bg-secondary/10 border border-secondary/30 rounded-lg p-4 mb-6 flex items-center gap-3">
              <CheckCircle className="w-5 h-5 text-secondary flex-shrink-0" />
              <div>
                <p className="font-semibold text-secondary">{t('App installiert', 'App Installed')}</p>
                <p className="text-sm text-muted-foreground">{t('delfinitx ist einsatzbereit', 'delfinitx is ready to use')}</p>
              </div>
            </div>
          )}

          {/* Installation Card */}
          <div className="bg-card border border-border rounded-lg p-6 shadow-sm">
            {!isInstalled ? (
              <>
                <h2 className="text-lg font-semibold text-foreground mb-4">{t('Installationsoptionen', 'Installation Options')}</h2>

                {/* Android Installation */}
                {isAndroid && (
                  <div className="space-y-3">
                    <p className="text-sm text-muted-foreground mb-4">
                      {t('Installieren Sie delfinitx direkt auf Ihrem Android-Gerät', 'Install delfinitx directly on your Android device')}
                    </p>
                    <Button
                      onClick={handleAndroidInstall}
                      disabled={!deferredPrompt}
                      className="w-full bg-primary hover:bg-primary/90 text-primary-foreground h-12 rounded-lg font-semibold flex items-center justify-center gap-2"
                    >
                      <Chrome className="w-5 h-5" />
                      {t('App installieren', 'Install App')}
                    </Button>
                    {!deferredPrompt && (
                      <p className="text-xs text-muted-foreground text-center mt-2">
                        {t('Installationshinweis nicht verfügbar. Versuchen Sie es erneut oder nutzen Sie das Browser-Menü.', 'Installation prompt not available. Try again or use your browser menu.')}
                      </p>
                    )}
                  </div>
                )}

                {/* iOS Installation */}
                {isIOS && (
                  <div className="space-y-3">
                    <p className="text-sm text-muted-foreground mb-4">
                      {t('Fügen Sie delfinitx auf iOS zum Startbildschirm hinzu', 'Add delfinitx to your home screen on iOS')}
                    </p>
                    <Button
                      onClick={handleIOSInstall}
                      className="w-full bg-primary hover:bg-primary/90 text-primary-foreground h-12 rounded-lg font-semibold flex items-center justify-center gap-2"
                    >
                      <Apple className="w-5 h-5" />
                      {t('Zum Startbildschirm hinzufügen', 'Add to Home Screen')}
                    </Button>
                  </div>
                )}

                {/* Desktop/Other */}
                {!isAndroid && !isIOS && (
                  <div className="space-y-3">
                    <p className="text-sm text-muted-foreground mb-4">
                      {t('Öffnen Sie diese Seite auf Ihrem Mobilgerät, um die App zu installieren', 'Open this page on your mobile device to install the app')}
                    </p>
                    <div className="bg-muted/50 rounded-lg p-4 text-center">
                      <p className="text-sm font-medium text-foreground">
                        delfinitx.com/install-app
                      </p>
                    </div>
                  </div>
                )}
              </>
            ) : (
              <div className="text-center py-4">
                <p className="text-foreground font-semibold mb-2">{t('Bereit zum Loslegen!', 'Ready to go!')}</p>
                <p className="text-sm text-muted-foreground">
                  {t('Öffnen Sie delfinitx aus Ihrem App-Drawer oder Startbildschirm', 'Open delfinitx from your app drawer or home screen')}
                </p>
              </div>
            )}
          </div>

          {/* Info Section */}
          <div className="mt-6 bg-accent/50 rounded-lg p-4 text-sm text-foreground/80">
            <p className="font-semibold mb-2">{t('Warum die App installieren?', 'Why install the app?')}</p>
            <ul className="space-y-1 text-xs">
              <li>✓ {t('Schneller Zugriff vom Startbildschirm', 'Fast access from your home screen')}</li>
              <li>✓ {t('Funktioniert offline mit zwischengespeicherten Daten', 'Works offline with cached data')}</li>
              <li>✓ {t('Vollbild-Erlebnis ohne Browser-Oberfläche', 'Full-screen experience without browser UI')}</li>
              <li>✓ {t('Push-Benachrichtigungen für Updates', 'Push notifications for updates')}</li>
            </ul>
          </div>
        </div>
      </div>

      {/* iOS Instructions Modal */}
      <Dialog open={showIOSInstructions} onOpenChange={setShowIOSInstructions}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle>{t('Zum Startbildschirm hinzufügen', 'Add to Home Screen')}</DialogTitle>
            <DialogDescription>
              {t('Folgen Sie diesen Schritten, um delfinitx auf Ihrem iPhone zu installieren', 'Follow these steps to install delfinitx on your iPhone')}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <div className="flex items-start gap-3">
                <div className="flex-shrink-0 w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center text-xs font-semibold text-primary">
                  1
                </div>
                <div>
                  <p className="font-semibold text-foreground">{t('Tippen Sie auf die Teilen-Schaltfläche', 'Tap the Share button')}</p>
                  <p className="text-sm text-muted-foreground">
                    {t('Suchen Sie nach dem Quadrat mit Pfeil am unteren Bildschirmrand', 'Look for the square with an arrow at the bottom of your screen')}
                  </p>
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex items-start gap-3">
                <div className="flex-shrink-0 w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center text-xs font-semibold text-primary">
                  2
                </div>
                <div>
                  <p className="font-semibold text-foreground">{t('Scrollen und „Zum Startbildschirm hinzufügen" tippen', 'Scroll and tap "Add to Home Screen"')}</p>
                  <p className="text-sm text-muted-foreground">
                    {t('Möglicherweise müssen Sie nach unten scrollen, um diese Option zu finden', 'You may need to scroll down to find this option')}
                  </p>
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex items-start gap-3">
                <div className="flex-shrink-0 w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center text-xs font-semibold text-primary">
                  3
                </div>
                <div>
                  <p className="font-semibold text-foreground">{t('Namen bestätigen', 'Confirm the name')}</p>
                  <p className="text-sm text-muted-foreground">
                    {t('Tippen Sie auf „Hinzufügen", um zu bestätigen und die App zu installieren', 'Tap "Add" to confirm and install the app')}
                  </p>
                </div>
              </div>
            </div>
          </div>

          <Button
            onClick={() => setShowIOSInstructions(false)}
            className="w-full bg-primary hover:bg-primary/90 text-primary-foreground"
          >
            {t('Verstanden', 'Got it')}
          </Button>
        </DialogContent>
      </Dialog>
    </>
  );
}
