import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { Globe, Users, ShieldCheck } from 'lucide-react';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import { Card, CardContent } from '@/components/ui/card';
import { useLanguage } from '@/i18n/LanguageContext.jsx';

const AboutPage = () => {
  const { t } = useLanguage();
  const fadeInUp = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.6 } }
  };

  const staggerContainer = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.1 }
    }
  };

  const executives = [
    { name: 'Kris Marszalek', role: t('Mitgründer & CEO', 'Co-Founder & CEO'), initials: 'KM' },
    { name: 'Rafael Melo', role: t('Mitgründer & CFO', 'Co-Founder & CFO'), initials: 'RM' },
    { name: 'Bobby Bao', role: t('Mitgründer, Leiter Crypto.com Capital', 'Co-Founder, Head of Crypto.com Capital'), initials: 'BB' }
  ];

  const values = [
    { title: t('Klar denken', 'Think Clearly'), description: t('Wir priorisieren Klarheit im Denken und in der Kommunikation.', 'We prioritize clarity of thought and communication.') },
    { title: t('Ressourcenstark sein', 'Be Resourceful'), description: t('Wir finden kreative Lösungen für komplexe Probleme.', 'We find creative solutions to complex problems.') },
    { title: t('Entschlossen bleiben', 'Stay Determined'), description: t('Wir behalten die Beharrlichkeit durch Herausforderungen und Marktzyklen.', 'We persevere through challenges and market cycles.') },
    { title: t('Groß denken', 'Dream Big'), description: t('Wir streben nach globaler Wirkung und massivem Maßstab.', 'We aim for global impact and massive scale.') },
    { title: t('Verantwortung übernehmen & entscheidungsfreudig sein', 'Take Ownership and Be Decisive'), description: t('Wir handeln mit Verantwortung und Geschwindigkeit.', 'We act with accountability and speed.') },
    { title: t('Bescheiden bleiben', 'Remain Humble'), description: t('Wir lernen aus unseren Fehlern und schätzen jeden Beitrag.', 'We learn from our mistakes and value every contribution.') }
  ];

  return (
    <>
      <Helmet>
        <title>{t('Über uns | delfinitx', 'About Us | delfinitx')}</title>
        <meta name="description" content={t('Erfahren Sie mehr über unsere Vision, Mission, unser Team und unsere Kernwerte, während wir den Übergang der Welt zu Kryptowährung beschleunigen.', 'Learn about our vision, mission, team, and core values as we accelerate the world\'s transition to cryptocurrency.')} />
      </Helmet>

      <div className="min-h-screen flex flex-col bg-background">
        <Header />

        <main className="flex-1">
          {/* VISION SECTION */}
          <section className="py-24 md:py-32 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto text-center">
            <motion.div initial="hidden" animate="visible" variants={fadeInUp}>
              <h2 className="text-sm font-bold tracking-widest text-primary uppercase mb-4">{t('Unsere Vision', 'Our Vision')}</h2>
              <h1 className="text-5xl md:text-7xl font-extrabold tracking-tight text-balance mb-6">
                {t('Kryptowährung in jeder Wallet', 'Cryptocurrency in Every Wallet')}
              </h1>
            </motion.div>
          </section>

          {/* MISSION SECTION */}
          <section className="py-20 bg-muted/50 border-y border-border">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
              <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeInUp}>
                <h2 className="text-sm font-bold tracking-widest text-secondary-foreground uppercase mb-4">{t('Unsere Mission', 'Our Mission')}</h2>
                <p className="text-3xl md:text-4xl font-semibold text-balance mb-8 max-w-4xl mx-auto leading-snug">
                  {t('Den Übergang der Welt zu Kryptowährung beschleunigen', 'Accelerate the world\'s transition to cryptocurrency')}
                </p>
              </motion.div>
            </div>
          </section>

          {/* PARTNERS SECTION */}
          <section className="py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeInUp}>
              <h2 className="text-sm font-bold tracking-widest text-primary uppercase mb-4">{t('Unsere Partner', 'Our Partners')}</h2>
              <p className="text-2xl md:text-3xl font-medium text-balance mb-8 max-w-3xl mx-auto">
                {t('Die nächsten Milliarde Nutzer mit den besten Partnern der Welt erreichen', 'Reaching the next billion users with the world\'s best partners')}
              </p>
            </motion.div>
          </section>

          {/* TEAM & EXECUTIVES SECTION */}
          <section className="py-24 bg-card border-y border-border">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 mb-20">
                <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeInUp}>
                  <h2 className="text-sm font-bold tracking-widest text-primary uppercase mb-4">{t('Unser Team', 'Our Team')}</h2>
                  <h3 className="text-4xl font-bold tracking-tight mb-6">{t('Eine Vision, ein globales Team', 'One Vision, One Global Team')}</h3>
                  <p className="text-lg text-muted-foreground leading-relaxed mb-8">
                    {t('Wir sind eine vielfältige Gruppe von Bauern, Ingenieuren und Visionären, die weltweit an der Zukunft der Finanzen arbeitet. Unser Team ist durch eine gemeinsame Leidenschaft für Dezentralisierung und finanzielle Ermächtigung vereint.', 'We are a diverse group of builders, engineers, and visionaries working across the globe to build the future of finance. Our team is united by a shared passion for decentralization and financial empowerment.')}
                  </p>
                  <div className="flex gap-8 mb-8">
                    <div>
                      <div className="flex items-center gap-2 text-3xl font-bold text-foreground mb-1">
                        <Users className="w-8 h-8 text-primary" />
                        150M+
                      </div>
                      <div className="text-sm text-muted-foreground font-medium">{t('Nutzer weltweit', 'Users Worldwide')}</div>
                    </div>
                    <div>
                      <div className="flex items-center gap-2 text-3xl font-bold text-foreground mb-1">
                        <Globe className="w-8 h-8 text-primary" />
                        90+
                      </div>
                      <div className="text-sm text-muted-foreground font-medium">{t('Länder', 'Countries')}</div>
                    </div>
                  </div>
                </motion.div>

                <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={staggerContainer}>
                  <div className="mb-8">
                    <h3 className="text-2xl font-bold">{t('Lernen Sie unser Führungsteam kennen', 'Meet Our Executive Team')}</h3>
                  </div>
                  <div className="space-y-4">
                    {executives.map((exec, idx) => (
                      <motion.div key={idx} variants={fadeInUp}>
                        <Card className="border-none shadow-sm bg-muted/50 hover:bg-muted transition-colors">
                          <CardContent className="p-4 flex items-center gap-4">
                            <div className="w-12 h-12 rounded-xl bg-primary/10 text-primary flex items-center justify-center font-bold text-lg">
                              {exec.initials}
                            </div>
                            <div>
                              <div className="font-bold text-foreground">{exec.name}</div>
                              <div className="text-sm text-muted-foreground">{exec.role}</div>
                            </div>
                          </CardContent>
                        </Card>
                      </motion.div>
                    ))}
                  </div>
                </motion.div>
              </div>
            </div>
          </section>

          {/* VALUES & SECURITY SECTION */}
          <section className="py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
              <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={fadeInUp}>
                <div className="relative rounded-3xl overflow-hidden bg-muted/30 p-8 border border-border mb-8">
                  <img
                    src="https://horizons-cdn.hostinger.com/203fccdc-e8bc-431c-9992-1395201ebaa1/94f7db78b09d33fa8fe6bc4de7171a7b.png"
                    alt={t('Sicherheitsschloss als Symbol für Vertrauen und Datenschutz', 'Security lock representing trust and data privacy')}
                    className="w-full max-w-md mx-auto object-contain drop-shadow-xl"
                  />
                </div>
                <div className="flex items-start gap-4">
                  <ShieldCheck className="w-8 h-8 text-primary shrink-0 mt-1" />
                  <div>
                    <h3 className="text-2xl font-bold mb-3">{t('Auf Vertrauen und Sicherheit gebaut', 'Built on Trust and Security')}</h3>
                    <p className="text-muted-foreground leading-relaxed">
                      {t('Vertrauen ist unsere wichtigste Währung. Wir verpflichten uns den höchsten Standards an Sicherheit und Datenschutz. Durch die Einbettung robuster Compliance- und Sicherheitsmaßnahmen in den Kern unserer Plattform stellen wir sicher, dass die Vermögenswerte und persönlichen Daten unserer Nutzer jederzeit geschützt sind.', 'Trust is our ultimate currency. We are committed to the highest standards of security and data privacy. By embedding robust compliance and security measures into the core of our platform, we ensure that our users\' assets and personal information are protected at all times.')}
                    </p>
                  </div>
                </div>
              </motion.div>

              <motion.div initial="hidden" whileInView="visible" viewport={{ once: true }} variants={staggerContainer}>
                <h2 className="text-sm font-bold tracking-widest text-primary uppercase mb-4">{t('Unsere Werte', 'Our Values')}</h2>
                <h3 className="text-3xl font-bold tracking-tight mb-8">{t('Die Prinzipien, die uns leiten', 'The principles that guide us')}</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  {values.map((value, idx) => (
                    <motion.div key={idx} variants={fadeInUp} className="bg-card border border-border rounded-2xl p-6 shadow-sm">
                      <div className="text-4xl font-black text-primary/10 mb-4">0{idx + 1}</div>
                      <h4 className="text-lg font-bold mb-2">{value.title}</h4>
                      <p className="text-sm text-muted-foreground leading-relaxed">{value.description}</p>
                    </motion.div>
                  ))}
                </div>
              </motion.div>
            </div>
          </section>
        </main>

        <Footer />
      </div>
    </>
  );
};

export default AboutPage;
