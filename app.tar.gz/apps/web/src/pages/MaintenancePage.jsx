import React from 'react';
import { Helmet } from 'react-helmet';
import { useLanguage } from '@/i18n/LanguageContext.jsx';

export default function MaintenancePage() {
  const { t } = useLanguage();
  return (
    <>
      <Helmet>
        <title>{t('Website in Wartung - delfinitx', 'Site Under Maintenance - delfinitx')}</title>
        <meta name="robots" content="noindex, nofollow" />
      </Helmet>

      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-background via-background to-muted px-4">
        {/* Animated background elements */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-20 right-20 w-72 h-72 bg-primary/5 rounded-full blur-3xl animate-pulse" />
          <div className="absolute bottom-20 left-20 w-72 h-72 bg-secondary/5 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }} />
        </div>

        {/* Content */}
        <div className="relative z-10 max-w-md w-full">
          <div className="bg-card border border-border rounded-2xl shadow-lg p-8 md:p-12 text-center">
            {/* Logo/Icon */}
            <div className="mb-8 flex justify-center">
              <div className="w-16 h-16 bg-gradient-to-br from-primary to-secondary rounded-full flex items-center justify-center">
                <svg
                  className="w-8 h-8 text-primary-foreground"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"
                  />
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"
                  />
                </svg>
              </div>
            </div>

            {/* Heading */}
            <h1 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
              {t('Website in Wartung', 'Site Under Maintenance')}
            </h1>

            {/* Description */}
            <p className="text-muted-foreground text-lg mb-8 leading-relaxed">
              {t('Wir aktualisieren die Website. Bitte kommen Sie bald wieder!', 'We are updating the site. Come back soon!')}
            </p>

            {/* Status indicator */}
            <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground mb-8">
              <div className="w-2 h-2 bg-secondary rounded-full animate-pulse" />
              <span>{t('Wartung läuft', 'Maintenance in progress')}</span>
            </div>

            {/* Footer text */}
            <p className="text-xs text-muted-foreground">
              {t('Vielen Dank für Ihre Geduld. Wir sind in Kürze wieder online.', 'Thank you for your patience. We\'ll be back online shortly.')}
            </p>
          </div>

          {/* Branding footer */}
          <div className="mt-8 text-center">
            <p className="text-sm text-muted-foreground">
              © 2026 delfinitx. {t('Alle Rechte vorbehalten.', 'All rights reserved.')}
            </p>
          </div>
        </div>
      </div>
    </>
  );
}
