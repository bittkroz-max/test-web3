import React, { useState, useEffect, useCallback } from 'react';
import { Helmet } from 'react-helmet';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { toast } from 'sonner';
import {
  Users, UserCheck, Clock, ArrowLeftRight, Check, X, Eye, Ban, Loader2, ShieldCheck, RefreshCw, Trash2, FileText, ExternalLink, Mail,
} from 'lucide-react';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import { Button } from '@/components/ui/button';
import pb from '@/lib/pocketbaseClient';
import { useAuth } from '@/hooks/useAuth.jsx';
import { useLanguage } from '@/i18n/LanguageContext.jsx';
import { sendTestNotification, NOTIFICATION_RECIPIENT } from '@/lib/emailNotifications.js';

const fmtDate = (d) => (d ? new Date(d).toLocaleString() : '—');

const StatCard = ({ icon: Icon, label, value, tint }) => (
  <div className="bg-card border border-border rounded-2xl p-5">
    <div className={`w-10 h-10 rounded-xl flex items-center justify-center mb-3 ${tint}`}>
      <Icon className="w-5 h-5" />
    </div>
    <p className="text-3xl font-bold price-text">{value}</p>
    <p className="text-sm text-muted-foreground mt-1">{label}</p>
  </div>
);

const AdminPage = () => {
  const { isAuthed, isAdmin, user, refresh } = useAuth();
  const { t } = useLanguage();
  const navigate = useNavigate();
  const [actioningId, setActioningId] = useState(null);
  const [tab, setTab] = useState('pending');
  const [clients, setClients] = useState([]);
  const [txs, setTxs] = useState([]);
  const [docs, setDocs] = useState([]);
  const [wallets, setWallets] = useState([]);
  const [walletModal, setWalletModal] = useState(null);
  const [walletForm, setWalletForm] = useState({ email: '', client_name: '', btc_address: '', eth_address: '', sol_address: '', usdt_address: '', btc_zpub: '' });
  const [savingWallet, setSavingWallet] = useState(false);
  const [editingWalletId, setEditingWalletId] = useState(null);
  const [loading, setLoading] = useState(true);
  const [detail, setDetail] = useState(null);
  const [testingEmail, setTestingEmail] = useState(false);

  const load = useCallback(async () => {
    try {
      const cacheBust = Date.now();
      const noCache = {
        cache: 'no-store',
        headers: { 'Cache-Control': 'no-cache, no-store, must-revalidate', Pragma: 'no-cache' },
      };
      const [usersList, transactions, documents, walletsList] = await Promise.all([
        pb.collection('users').getFullList({
          sort: '-created',
          requestKey: `admin-users-${cacheBust}`,
          query: { _: cacheBust },
          ...noCache,
        }),
        pb.collection('transactions').getFullList({
          sort: '-created',
          requestKey: `admin-txs-${cacheBust}`,
          query: { _: cacheBust },
          ...noCache,
        }),
        pb.collection('kyc_documents').getFullList({
          sort: '-created',
          requestKey: `admin-docs-${cacheBust}`,
          query: { _: cacheBust },
          ...noCache,
        }),
        pb.collection('client_wallets').getFullList({
          sort: 'email',
          requestKey: `admin-wallets-${cacheBust}`,
          query: { _: cacheBust },
          ...noCache,
        }).catch(() => []),
      ]);
      setClients(usersList.filter((u) => u.role !== 'admin'));
      setTxs(transactions);
      setDocs(documents);
      setWallets(walletsList);
    } catch (e) {
      console.error('Failed to load admin data', e);
      toast.error(t('Dashboard-Daten konnten nicht geladen werden', 'Could not load dashboard data'), { description: e?.message || t('Bitte aktualisieren Sie die Seite.', 'Please refresh the page.') });
    } finally {
      setLoading(false);
    }
  }, [t]);

  useEffect(() => {
    if (!isAuthed) { navigate('/login'); return; }
    if (!isAdmin) { navigate('/'); return; }
    refresh().finally(() => load());

    let usersUnsub = null;
    let txsUnsub = null;

    pb.collection('users').subscribe('*', (e) => {
      setClients((prev) => {
        if (e.action === 'delete') return prev.filter((c) => c.id !== e.record.id);
        const exists = prev.some((c) => c.id === e.record.id);
        if (e.record.role === 'admin') return prev.filter((c) => c.id !== e.record.id);
        if (exists) return prev.map((c) => (c.id === e.record.id ? e.record : c));
        return [e.record, ...prev];
      });
      load();
    }).then((unsub) => { usersUnsub = unsub; })
      .catch((err) => console.error('Realtime subscribe (users) failed', err));

    pb.collection('transactions').subscribe('*', () => { load(); })
      .then((unsub) => { txsUnsub = unsub; })
      .catch((err) => console.error('Realtime subscribe (transactions) failed', err));

    let docsUnsub = null;
    pb.collection('kyc_documents').subscribe('*', () => { load(); })
      .then((unsub) => { docsUnsub = unsub; })
      .catch((err) => console.error('Realtime subscribe (kyc_documents) failed', err));

    const pollId = setInterval(load, 3000);

    const onFocus = () => load();
    window.addEventListener('focus', onFocus);
    window.addEventListener('online', onFocus);
    document.addEventListener('visibilitychange', onFocus);

    return () => {
      pb.collection('users').unsubscribe('*');
      pb.collection('transactions').unsubscribe('*');
      pb.collection('kyc_documents').unsubscribe('*');
      if (usersUnsub) { try { usersUnsub(); } catch (_) { /* noop */ } }
      if (txsUnsub) { try { txsUnsub(); } catch (_) { /* noop */ } }
      if (docsUnsub) { try { docsUnsub(); } catch (_) { /* noop */ } }
      clearInterval(pollId);
      window.removeEventListener('focus', onFocus);
      window.removeEventListener('online', onFocus);
      document.removeEventListener('visibilitychange', onFocus);
    };
  }, [isAuthed, isAdmin, navigate, load, refresh]);

  const pending = clients.filter((c) => c.status === 'pending');
  const approved = clients.filter((c) => c.status === 'approved');

  const updateClientStatus = async (client, nextStatus) => {
    if (actioningId) return;
    setActioningId(client.id);

    try {
      await refresh().catch(() => {});

      const payload = nextStatus === 'approved'
        ? { status: 'approved', approvedAt: new Date().toISOString() }
        : { status: 'rejected' };

      const updated = await pb.collection('users').update(client.id, payload, {
        requestKey: `admin-update-${client.id}-${Date.now()}`,
      });

      setClients((prev) => prev.map((c) => (c.id === client.id ? updated : c)));

      if (nextStatus === 'approved') {
        toast.success(t('Kunde genehmigt', 'Client approved'), { description: `${client.email || t('Der Kunde', 'The client')} ` + t('kann nun auf die Wallet zugreifen — eine Login-E-Mail ist unterwegs.', 'can now access the wallet — a login email is on its way.') });
      } else {
        toast.success(t('Kunde abgelehnt', 'Client rejected'), { description: `${client.email || t('Der Kunde', 'The client')} ` + t('wurde abgelehnt und per E-Mail benachrichtigt.', 'has been rejected and notified by email.') });
      }

      load();
    } catch (err) {
      console.error(`Failed to ${nextStatus === 'approved' ? 'approve' : 'reject'} client`, err);
      const detailMsg = err?.response?.data
        ? Object.values(err.response.data).map((f) => f?.message).filter(Boolean).join(', ')
        : err?.message;
      toast.error(
        nextStatus === 'approved' ? t('Genehmigung fehlgeschlagen', 'Approval failed') : t('Ablehnung fehlgeschlagen', 'Rejection failed'),
        { description: detailMsg || t('Dieser Kunde konnte nicht aktualisiert werden. Bitte erneut versuchen.', 'This client could not be updated. Please try again.') },
      );
    } finally {
      setActioningId(null);
    }
  };

  const approve = (client) => updateClientStatus(client, 'approved');
  const reject = (client) => updateClientStatus(client, 'rejected');

  const deleteClient = async (client) => {
    const confirmed = window.confirm(t('Sei sicuro di voler cancellare definitivamente', 'Are you sure you want to permanently delete') + ` ${client.email}? ` + t('Questa azione è irreversibile e libererà la sua email per una nuova registrazione.', 'This action is irreversible and will free the email for a new registration.'));
    if (!confirmed) return;

    setActioningId(client.id);
    try {
      await refresh().catch(() => {});

      console.log(`[DELETE] Requesting permanent removal of ${client.email} (${client.id}) from database...`);

      const res = await pb.send('/api/admin-delete-user', {
        method: 'POST',
        body: { userId: client.id },
        requestKey: `admin-delete-user-${client.id}-${Date.now()}`,
      });

      console.log('[DELETE] Server response:', res);

      let stillExists = true;
      try {
        await pb.collection('users').getOne(client.id, {
          requestKey: `admin-verify-delete-${client.id}-${Date.now()}`,
        });
      } catch (verifyErr) {
        if (verifyErr?.status === 404) stillExists = false;
      }

      if (stillExists) {
        throw new Error(t('Il cliente risulta ancora presente nel database dopo la cancellazione.', 'The client still exists in the database after deletion.'));
      }

      console.log(`[DELETE] Confirmed: ${client.email} no longer exists in the database. Email freed for re-registration.`);

      setClients((prev) => prev.filter((c) => c.id !== client.id));
      toast.success(t('Cliente cancellato definitivamente', 'Client permanently deleted'), {
        description: `${client.email} ` + t('è stato COMPLETAMENTE rimosso dal database. La sua email è ora disponibile per una nuova registrazione.', 'has been COMPLETELY removed from the database. The email is now available for a new registration.'),
      });
      load();
    } catch (err) {
      console.error('Failed to delete client', err);
      const detailMsg = err?.response?.data?.message
        || (err?.response?.data ? Object.values(err.response.data).map((f) => f?.message).filter(Boolean).join(', ') : null)
        || err?.message;
      toast.error(t('Cancellazione fallita', 'Deletion failed'), { description: detailMsg || t('Non è stato possibile cancellare questo cliente. Riprova.', 'Could not delete this client. Please try again.') });
    } finally {
      setActioningId(null);
    }
  };

  const reviewDocument = async (doc, nextStatus) => {
    if (actioningId) return;
    setActioningId(doc.id);
    try {
      await refresh().catch(() => {});
      const updated = await pb.collection('kyc_documents').update(doc.id, {
        status: nextStatus,
        reviewedAt: new Date().toISOString(),
      }, { requestKey: `admin-doc-${doc.id}-${Date.now()}` });
      setDocs((prev) => prev.map((d) => (d.id === doc.id ? updated : d)));
      toast.success(nextStatus === 'approved' ? t('Dokumente genehmigt', 'Documents approved') : t('Dokumente abgelehnt', 'Documents rejected'), {
        description: `${doc.email || t('Der Kunde', 'The client')} ` + t('wurde über den ', 'was notified of the ') + `${nextStatus}` + t('-Status benachrichtigt.', ' status.'),
      });
      load();
    } catch (err) {
      console.error('Failed to review document', err);
      toast.error(t('Aktion fehlgeschlagen', 'Action failed'), { description: err?.message || t('Dieses Dokument konnte nicht aktualisiert werden.', 'This document could not be updated.') });
    } finally {
      setActioningId(null);
    }
  };

  const deactivate = async (client) => {
    try {
      const updated = await pb.collection('users').update(client.id, { status: 'disabled' }, {
        requestKey: `admin-disable-${client.id}`,
      });
      setClients((prev) => prev.map((c) => (c.id === client.id ? updated : c)));
      toast.success(t('Kunde deaktiviert', 'Client deactivated'), { description: `${client.email} ` + t('hat keinen Wallet-Zugriff mehr.', 'no longer has wallet access.') });
      load();
    } catch (err) {
      console.error('Failed to disable client', err);
      toast.error(t('Deaktivierung fehlgeschlagen', 'Deactivation failed'), { description: err?.message || t('Dieser Kunde konnte nicht deaktiviert werden.', 'This client could not be deactivated.') });
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 flex items-center justify-center"><Loader2 className="w-8 h-8 animate-spin text-primary" /></main>
        <Footer />
      </div>
    );
  }

  const tabs = [
    { key: 'pending', label: `${t('Ausstehend', 'Pending')} (${pending.length})` },
    { key: 'approved', label: `${t('Genehmigt', 'Approved')} (${approved.length})` },
    { key: 'transactions', label: `${t('Transaktionen', 'Transactions')} (${txs.length})` },
    { key: 'documents', label: `${t('Dokumente', 'Documents')} (${docs.filter((d) => d.status === 'pending').length})` },
    { key: 'wallets', label: `${t('Wallets', 'Wallets')} (${wallets.length})` },
    { key: 'stats', label: t('Statistik', 'Statistics') },
  ];

  return (
    <>
      <Helmet><title>{t('delfinitx - delfinitx', 'delfinitx - delfinitx')}</title></Helmet>
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 max-w-6xl w-full mx-auto px-4 sm:px-6 py-10">
          <div className="flex items-center justify-between flex-wrap gap-3 mb-8">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-xl bg-primary/10 flex items-center justify-center">
                <ShieldCheck className="w-6 h-6 text-primary" />
              </div>
              <div>
                <h1 className="text-xl font-bold leading-none">{t('delfinitx Dashboard', 'delfinitx Dashboard')}</h1>
                <p className="text-xs text-muted-foreground mt-1">{user?.email}</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Button variant="outline" size="sm" disabled={testingEmail} onClick={async () => {
                setTestingEmail(true);
                toast.info(t('Test-Benachrichtigung wird gesendet …', 'Sending test notification…'), { description: `${t('An', 'To')} ${NOTIFICATION_RECIPIENT}` });
                const res = await sendTestNotification();
                setTestingEmail(false);
                if (res.ok) {
                  toast.success(t('Test-Benachrichtigung gesendet', 'Test notification sent'), { description: `${t('Prüfen Sie den Posteingang von', 'Check the inbox of')} ${NOTIFICATION_RECIPIENT}. ${t('Details in der Browser-Konsole.', 'Details in the browser console.')}` });
                } else {
                  toast.error(t('Test-Benachrichtigung fehlgeschlagen', 'Test notification failed'), { description: res.error || t('Unbekannter Fehler — Browser-Konsole prüfen.', 'Unknown error — check browser console.') });
                }
              }} className="gap-1.5">
                {testingEmail ? <Loader2 className="w-4 h-4 animate-spin" /> : <Mail className="w-4 h-4" />}
                {t('EmailJS testen', 'Test EmailJS')}
              </Button>
              <Button variant="ghost" size="icon" onClick={load} aria-label={t('Aktualisieren', 'Refresh')}><RefreshCw className="w-5 h-5" /></Button>
            </div>
          </div>

          <div className="flex gap-2 mb-6 flex-wrap">
            {tabs.map((tt) => (
              <button key={tt.key} type="button" onClick={() => setTab(tt.key)}
                className={`px-4 py-2 rounded-xl text-sm font-semibold transition-colors ${tab === tt.key ? 'bg-primary text-primary-foreground' : 'bg-muted text-muted-foreground hover:text-foreground'}`}>
                {tt.label}
              </button>
            ))}
          </div>

          <motion.div key={tab} initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}>
            {tab === 'pending' && (
              <TableCard columns={[t('E-Mail', 'Email'), t('Name', 'Name'), t('Registriert', 'Registered'), t('Verifiziert', 'Verified'), t('Aktionen', 'Actions')]}>
                {pending.length === 0 ? <EmptyRow cols={5} text={t('Keine ausstehenden Kunden.', 'No pending clients.')} /> : pending.map((c) => (
                  <tr key={c.id} className="border-t border-border">
                    <td className="px-4 py-3 text-sm">{c.email}</td>
                    <td className="px-4 py-3 text-sm">{c.name || '—'}</td>
                    <td className="px-4 py-3 text-sm text-muted-foreground">{fmtDate(c.created)}</td>
                    <td className="px-4 py-3 text-sm">{c.verified ? <span className="text-secondary">{t('Ja', 'Yes')}</span> : <span className="text-muted-foreground">{t('Nein', 'No')}</span>}</td>
                    <td className="px-4 py-3">
                      <div className="flex gap-2 flex-wrap">
                        <Button
                          type="button"
                          size="sm"
                          disabled={actioningId === c.id}
                          onClick={() => approve(c)}
                          className="bg-secondary text-secondary-foreground hover:bg-secondary/90 h-8 gap-1"
                        >
                          {actioningId === c.id ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}
                          {t('Genehmigen', 'Approve')}
                        </Button>
                        <Button
                          type="button"
                          size="sm"
                          variant="destructive"
                          disabled={actioningId === c.id}
                          onClick={() => reject(c)}
                          className="h-8 gap-1"
                        >
                          {actioningId === c.id ? <Loader2 className="w-4 h-4 animate-spin" /> : <X className="w-4 h-4" />}
                          {t('Ablehnen', 'Reject')}
                        </Button>
                        <Button
                          type="button"
                          size="sm"
                          variant="outline"
                          disabled={actioningId === c.id}
                          onClick={() => deleteClient(c)}
                          className="h-8 gap-1 text-destructive border-destructive hover:bg-destructive/10"
                        >
                          {actioningId === c.id ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
                          {t('Löschen', 'Delete')}
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </TableCard>
            )}

            {tab === 'approved' && (
              <TableCard columns={[t('E-Mail', 'Email'), t('Name', 'Name'), t('Genehmigt', 'Approved'), t('Aktionen', 'Actions')]}>
                {approved.length === 0 ? <EmptyRow cols={4} text={t('Keine genehmigten Kunden.', 'No approved clients.')} /> : approved.map((c) => (
                  <tr key={c.id} className="border-t border-border">
                    <td className="px-4 py-3 text-sm">{c.email}</td>
                    <td className="px-4 py-3 text-sm">{c.name || '—'}</td>
                    <td className="px-4 py-3 text-sm text-muted-foreground">{fmtDate(c.approvedAt)}</td>
                    <td className="px-4 py-3">
                      <div className="flex gap-2 flex-wrap">
                        <Button type="button" size="sm" variant="outline" onClick={() => setDetail(c)} className="h-8 gap-1"><Eye className="w-4 h-4" />{t('Details', 'Details')}</Button>
                        <Button type="button" size="sm" variant="destructive" onClick={() => deactivate(c)} className="h-8 gap-1"><Ban className="w-4 h-4" />{t('Deaktivieren', 'Deactivate')}</Button>
                        <Button
                          type="button"
                          size="sm"
                          variant="outline"
                          disabled={actioningId === c.id}
                          onClick={() => deleteClient(c)}
                          className="h-8 gap-1 text-destructive border-destructive hover:bg-destructive/10"
                        >
                          {actioningId === c.id ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
                          {t('Löschen', 'Delete')}
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </TableCard>
            )}

            {tab === 'transactions' && (
              <TableCard columns={[t('Kunde', 'Client'), t('Betrag (BTC)', 'Amount (BTC)'), t('Empfänger', 'Recipient'), t('Datum', 'Date'), t('Status', 'Status')]}>
                {txs.length === 0 ? <EmptyRow cols={5} text={t('Noch keine Transaktionen.', 'No transactions yet.')} /> : txs.map((tx) => (
                  <tr key={tx.id} className="border-t border-border">
                    <td className="px-4 py-3 text-sm">{tx.email || '—'}</td>
                    <td className="px-4 py-3 text-sm price-text">{tx.amount}</td>
                    <td className="px-4 py-3 text-sm break-all max-w-[200px]">{tx.recipient}</td>
                    <td className="px-4 py-3 text-sm text-muted-foreground">{fmtDate(tx.created)}</td>
                    <td className="px-4 py-3 text-sm text-secondary">{tx.status}</td>
                  </tr>
                ))}
              </TableCard>
            )}

            {tab === 'documents' && (
              <TableCard columns={[t('Kunde', 'Client'), t('Typ', 'Type'), t('Dateien', 'Files'), t('Eingereicht', 'Submitted'), t('Status', 'Status'), t('Aktionen', 'Actions')]}>
                {docs.length === 0 ? <EmptyRow cols={6} text={t('Noch keine Dokumente eingereicht.', 'No documents submitted yet.')} /> : docs.map((d) => {
                  const typeLabel = d.docType === 'id_card' ? t('Personalausweis', 'ID Card') : d.docType === 'drivers_license' ? t('Führerschein', "Driver's License") : d.docType === 'passport' ? t('Reisepass', 'Passport') : '—';
                  const files = Array.isArray(d.documents) ? d.documents : (d.documents ? [d.documents] : []);
                  return (
                    <tr key={d.id} className="border-t border-border align-top">
                      <td className="px-4 py-3 text-sm">{d.email || '—'}</td>
                      <td className="px-4 py-3 text-sm">{typeLabel}</td>
                      <td className="px-4 py-3 text-sm">
                        <div className="flex flex-col gap-1">
                          {files.map((f, i) => (
                            <a key={f} href={pb.files.getURL(d, f)} target="_blank" rel="noreferrer"
                              className="inline-flex items-center gap-1.5 text-primary hover:underline">
                              <FileText className="w-4 h-4" />{t('Dokument', 'Document')} {i + 1}<ExternalLink className="w-3 h-3" />
                            </a>
                          ))}
                          {files.length === 0 && '—'}
                        </div>
                      </td>
                      <td className="px-4 py-3 text-sm text-muted-foreground">{fmtDate(d.created)}</td>
                      <td className="px-4 py-3 text-sm">
                        {d.status === 'approved' ? <span className="text-secondary">{t('Verifiziert', 'Verified')}</span>
                          : d.status === 'rejected' ? <span className="text-destructive">{t('Abgelehnt', 'Rejected')}</span>
                            : <span className="text-primary">{t('Ausstehend', 'Pending')}</span>}
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex gap-2 flex-wrap">
                          <Button type="button" size="sm" disabled={actioningId === d.id || d.status === 'approved'}
                            onClick={() => reviewDocument(d, 'approved')}
                            className="bg-secondary text-secondary-foreground hover:bg-secondary/90 h-8 gap-1">
                            {actioningId === d.id ? <Loader2 className="w-4 h-4 animate-spin" /> : <Check className="w-4 h-4" />}{t('Genehmigen', 'Approve')}
                          </Button>
                          <Button type="button" size="sm" variant="destructive" disabled={actioningId === d.id || d.status === 'rejected'}
                            onClick={() => reviewDocument(d, 'rejected')} className="h-8 gap-1">
                            {actioningId === d.id ? <Loader2 className="w-4 h-4 animate-spin" /> : <X className="w-4 h-4" />}{t('Ablehnen', 'Reject')}
                          </Button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </TableCard>
            )}

            {tab === 'wallets' && (
              <div className="space-y-4">
                <div className="flex justify-end">
                  <Button type="button" onClick={() => { setWalletForm({ email: '', client_name: '', btc_address: '', eth_address: '', sol_address: '', usdt_address: '', btc_zpub: '' }); setEditingWalletId(null); setWalletModal('form'); }} className="gap-2">+ {t('Wallet hinzufügen', 'Add wallet')}</Button>
                </div>
                <TableCard columns={[t('Kunde', 'Client'), t('E-Mail', 'Email'), 'BTC', 'ETH', 'SOL', 'USDT', t('Aktionen', 'Actions')]}>
                  {wallets.length === 0 ? <EmptyRow cols={7} text={t('Noch keine Wallet-Zuweisungen.', 'No wallet assignments yet.')} /> : wallets.map((w) => (
                    <tr key={w.id} className="border-t border-border">
                      <td className="px-4 py-3 text-sm font-medium">{w.client_name || '—'}</td>
                      <td className="px-4 py-3 text-sm">{w.email}</td>
                      <td className="px-4 py-3 text-xs font-mono max-w-[120px] truncate" title={w.btc_address}>{w.btc_address || '—'}</td>
                      <td className="px-4 py-3 text-xs font-mono max-w-[100px] truncate" title={w.eth_address}>{w.eth_address || '—'}</td>
                      <td className="px-4 py-3 text-xs font-mono max-w-[100px] truncate" title={w.sol_address}>{w.sol_address || '—'}</td>
                      <td className="px-4 py-3 text-xs font-mono max-w-[100px] truncate" title={w.usdt_address}>{w.usdt_address || '—'}</td>
                      <td className="px-4 py-3">
                        <div className="flex gap-2">
                          <Button type="button" size="sm" variant="outline" className="h-8 gap-1" onClick={() => { setWalletForm({ email: w.email, client_name: w.client_name || '', btc_address: w.btc_address || '', eth_address: w.eth_address || '', sol_address: w.sol_address || '', usdt_address: w.usdt_address || '', btc_zpub: w.btc_zpub || '' }); setEditingWalletId(w.id); setWalletModal('form'); }}><Eye className="w-4 h-4" />{t('Bearbeiten', 'Edit')}</Button>
                          <Button type="button" size="sm" variant="outline" className="h-8 gap-1 text-destructive border-destructive hover:bg-destructive/10" onClick={async () => { if (!window.confirm(`${t('Wallet für', 'Delete wallet for')} ${w.email} ${t('löschen?', '?')}`)) return; try { await pb.collection('client_wallets').delete(w.id); setWallets((prev) => prev.filter((x) => x.id !== w.id)); toast.success(t('Wallet gelöscht', 'Wallet deleted')); } catch (e) { toast.error(t('Löschen fehlgeschlagen', 'Deletion failed'), { description: e?.message }); } }}><Trash2 className="w-4 h-4" />{t('Löschen', 'Delete')}</Button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </TableCard>
              </div>
            )}

            {tab === 'stats' && (
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                <StatCard icon={Users} label={t('Registrierte Kunden', 'Registered clients')} value={clients.length} tint="bg-primary/10 text-primary" />
                <StatCard icon={UserCheck} label={t('Genehmigte Kunden', 'Approved clients')} value={approved.length} tint="bg-secondary/10 text-secondary" />
                <StatCard icon={Clock} label={t('Ausstehende Kunden', 'Pending clients')} value={pending.length} tint="bg-orange-500/10 text-orange-500" />
                <StatCard icon={ArrowLeftRight} label={t('Transaktionen gesamt', 'Total transactions')} value={txs.length} tint="bg-blue-500/10 text-blue-500" />
              </div>
            )}
          </motion.div>
        </main>
        <Footer />
      </div>

      {walletModal === 'form' && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}
          className="fixed inset-0 z-[110] flex items-center justify-center bg-black/60 px-4" onClick={() => setWalletModal(null)}>
          <div className="bg-card w-full max-w-lg rounded-2xl border border-border p-6 max-h-[90vh] overflow-y-auto" onClick={(e) => e.stopPropagation()}>
            <h3 className="text-lg font-bold mb-5">{editingWalletId ? t('Wallet-Zuweisung bearbeiten', 'Edit wallet assignment') : t('Neue Wallet-Zuweisung', 'New wallet assignment')}</h3>
            <div className="space-y-4">
              {[
                { key: 'email', label: t('Kunden-E-Mail', 'Client email'), placeholder: 'kunde@beispiel.de', type: 'email', required: true },
                { key: 'client_name', label: t('Kundenname', 'Client name'), placeholder: t('Vollständiger Name', 'Full name'), type: 'text' },
                { key: 'btc_address', label: t('Bitcoin-Adresse (BTC)', 'Bitcoin address (BTC)'), placeholder: 'bc1q...', type: 'text' },
                { key: 'eth_address', label: t('Ethereum-Adresse (ETH)', 'Ethereum address (ETH)'), placeholder: '0x...', type: 'text' },
                { key: 'sol_address', label: t('Solana-Adresse (SOL)', 'Solana address (SOL)'), placeholder: t('Solana-Adresse...', 'Solana address...'), type: 'text' },
                { key: 'usdt_address', label: t('USDT-Adresse', 'USDT address'), placeholder: '0x...', type: 'text' },
                { key: 'btc_zpub', label: t('Bitcoin zpub (optional)', 'Bitcoin zpub (optional)'), placeholder: 'zpub...', type: 'text' },
              ].map(({ key, label, placeholder, type, required }) => (
                <div key={key}>
                  <label className="text-sm font-medium block mb-1">{label}{required && ' *'}</label>
                  <input type={type} value={walletForm[key]} onChange={(e) => setWalletForm((f) => ({ ...f, [key]: e.target.value }))}
                    placeholder={placeholder} className="w-full bg-background border border-input rounded-xl px-4 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-ring font-mono" />
                </div>
              ))}
              <div className="flex gap-3 pt-2">
                <Button type="button" variant="outline" className="flex-1" onClick={() => setWalletModal(null)}>{t('Abbrechen', 'Cancel')}</Button>
                <Button type="button" className="flex-1" disabled={savingWallet} onClick={async () => {
                  if (!walletForm.email) { toast.error(t('E-Mail ist erforderlich', 'Email is required')); return; }
                  setSavingWallet(true);
                  try {
                    await refresh().catch(() => {});
                    const payload = { ...walletForm };
                    if (editingWalletId) {
                      const updated = await pb.collection('client_wallets').update(editingWalletId, payload, { requestKey: `wallet-upd-${editingWalletId}` });
                      setWallets((prev) => prev.map((w) => (w.id === editingWalletId ? updated : w)));
                      toast.success(t('Wallet aktualisiert', 'Wallet updated'));
                    } else {
                      const created = await pb.collection('client_wallets').create(payload, { requestKey: `wallet-create-${Date.now()}` });
                      setWallets((prev) => [...prev, created]);
                      toast.success(t('Wallet zugewiesen', 'Wallet assigned'));
                    }
                    setWalletModal(null);
                  } catch (e) {
                    toast.error(t('Speichern fehlgeschlagen', 'Save failed'), { description: e?.message });
                  } finally {
                    setSavingWallet(false);
                  }
                }}>{savingWallet ? <Loader2 className="w-4 h-4 animate-spin" /> : (editingWalletId ? t('Änderungen speichern', 'Save changes') : t('Erstellen', 'Create'))}</Button>
              </div>
            </div>
          </div>
        </motion.div>
      )}

      {detail && (
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}
          className="fixed inset-0 z-[110] flex items-center justify-center bg-black/60 px-4" onClick={() => setDetail(null)}>
          <div className="bg-card w-full max-w-md rounded-2xl border border-border p-6" onClick={(e) => e.stopPropagation()}>
            <h3 className="text-lg font-bold mb-4">{t('Kundendetails', 'Client details')}</h3>
            <div className="space-y-2 text-sm">
              <Row label={t('Name', 'Name')} value={detail.name || '—'} />
              <Row label={t('E-Mail', 'Email')} value={detail.email} />
              <Row label={t('Status', 'Status')} value={detail.status} />
              <Row label={t('Verifiziert', 'Verified')} value={detail.verified ? t('Ja', 'Yes') : t('Nein', 'No')} />
              <Row label={t('Registriert', 'Registered')} value={fmtDate(detail.created)} />
              <Row label={t('Genehmigt', 'Approved')} value={fmtDate(detail.approvedAt)} />
            </div>
            <Button type="button" className="w-full mt-6" onClick={() => setDetail(null)}>{t('Schließen', 'Close')}</Button>
          </div>
        </motion.div>
      )}
    </>
  );
};

const Row = ({ label, value }) => (
  <div className="flex justify-between gap-4"><span className="text-muted-foreground">{label}</span><span className="font-medium break-all text-right">{value}</span></div>
);

const TableCard = ({ columns, children }) => (
  <div className="bg-card border border-border rounded-2xl overflow-hidden overflow-x-auto">
    <table className="w-full min-w-[600px]">
      <thead>
        <tr className="bg-muted/50">
          {columns.map((c) => <th key={c} className="px-4 py-3 text-left text-xs font-semibold text-muted-foreground uppercase tracking-wide">{c}</th>)}
        </tr>
      </thead>
      <tbody>{children}</tbody>
    </table>
  </div>
);

const EmptyRow = ({ cols, text }) => (
  <tr><td colSpan={cols} className="px-4 py-10 text-center text-sm text-muted-foreground">{text}</td></tr>
);

export default AdminPage;
