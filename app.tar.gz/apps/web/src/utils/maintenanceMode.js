/**
 * Maintenance Mode Toggle
 * 
 * To enable maintenance mode:
 * 1. Set MAINTENANCE_MODE to true below
 * 2. Reload the app
 * 
 * To disable maintenance mode:
 * 1. Set MAINTENANCE_MODE to false below
 * 2. Reload the app
 * 
 * The maintenance page will be shown to all users when enabled.
 */

export const MAINTENANCE_MODE = false;

export const isMaintenanceMode = () => {
  return MAINTENANCE_MODE;
};
