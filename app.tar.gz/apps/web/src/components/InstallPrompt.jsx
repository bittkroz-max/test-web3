import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Share, PlusSquare, Download } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { getInstallState, subscribeInstallPrompt, triggerInstallPrompt } from '@/lib/installPromptStore';
import { useLanguage } from '@/i18n/LanguageContext.jsx';

const STORAGE_KEY = 'delfinitx_pwa_prompt_dismissed_at';
const DISMISS_COOLDOWN_MS = 1000 * 60 * 60 * 24 * 7; // 7 days

function isStandalone() {
  return (
    window.matchMedia?.('(display-mode: standalone)').matches ||
    window.navigator.standalone === true
  );
}

function isIos() {
  return /iphone|ipad|ipod/i.test(window.navigator.userAgent) && !window.MSStream;
}

function wasRecentlyDismissed() {
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return false;
    return Date.now() - Number(raw) < DISMISS_COOLDOWN_MS;
  } catch {
    return false;
  }
}

const InstallPrompt = () => {
  const { t } = useLanguage();
  const [deferredEvent, setDeferredEvent] = useState(null);
  const [visible, setVisible] = useState(false);
  const [platform, setPlatform] = useState('android');

  useEffect(() => {
    if (isStandalone() || wasRecentlyDismissed()) {
      return;
    }

    if (isIos()) {
      setPlatform('ios');
      const timer = setTimeout(() => setVisible(true), 2500);
      return () => clearTimeout(timer);
    }

    setPlatform('android');

    const applyState = ({ deferredPrompt }) => {
      if (deferredPrompt) {
        setDeferredEvent(deferredPrompt);
        setVisible(true);
      }
    };

    applyState(getInstallState());
    const unsubscribe = subscribeInstallPrompt(applyState);
    return unsubscribe;
  }, []);

  const dismiss = () => {
    setVisible(false);
    try {
      window.localStorage.setItem(STORAGE_KEY, String(Date.now()));
    } catch {
      /* noop */
    }
  };

  const handleInstall = async () => {
    const choice = await triggerInstallPrompt();
    if (choice?.outcome === 'accepted' || choice?.outcome === 'dismissed') {
      dismiss();
    }
  };

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 40 }}
          transition={{ duration: 0.25, ease: 'easeOut' }}
          className="fixed inset-x-3 bottom-3 z-[70] sm:inset-x-auto sm:right-4 sm:bottom-4 sm:w-[380px]"
        >
          <div className="relative overflow-hidden rounded-2xl border border-border bg-card shadow-[0_20px_40px_-15px_rgba(113,50,245,0.35)]">
            <div className="flex items-start gap-3 p-4">
              <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-primary/10">
                <Download className="h-5 w-5 text-primary" strokeWidth={2} />
              </div>
              <div className="min-w-0 flex-1">
                <p className="text-sm font-semibold text-foreground">{t('delfinitx-App installieren', 'Install the delfinitx app')}</p>
                {platform === 'ios' ? (
                  <p className="mt-1 text-xs leading-relaxed text-muted-foreground">
                    {t('Tippen Sie auf ', 'Tap ')}<Share className="inline h-3.5 w-3.5 -mt-0.5" strokeWidth={2} /> {t(' Teilen, dann ', ' Share, then ')}{' '}
                    <span className="inline-flex items-center gap-0.5 font-medium text-foreground">
                      <PlusSquare className="h-3.5 w-3.5" strokeWidth={2} /> {t('Zum Startbildschirm hinzufügen', 'Add to Home Screen')}
                    </span>{' '}
                    {t('zum Installieren.', 'to install.')}
                  </p>
                ) : (
                  <p className="mt-1 text-xs leading-relaxed text-muted-foreground">
                    {t('Fügen Sie delfinitx zum Startbildschirm hinzu für schnellen, vollflächigen Zugriff – auch offline.', 'Add delfinitx to your home screen for fast, full-screen access — even offline.')}
                  </p>
                )}
                {platform === 'android' && (
                  <div className="mt-3 flex gap-2">
                    <Button size="sm" onClick={handleInstall} className="h-8 rounded-full px-4 text-xs">
                      {t('Installieren', 'Install')}
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={dismiss}
                      className="h-8 rounded-full px-3 text-xs text-muted-foreground"
                    >
                      {t('Nicht jetzt', 'Not now')}
                    </Button>
                  </div>
                )}
              </div>
              <button
                onClick={dismiss}
                aria-label={t('Installationshinweis schließen', 'Dismiss install prompt')}
                className="shrink-0 rounded-full p-1 text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
              >
                <X className="h-4 w-4" strokeWidth={2} />
              </button>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default InstallPrompt;
