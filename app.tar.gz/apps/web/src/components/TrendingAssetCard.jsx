import React from 'react';
import { TrendingUp, TrendingDown } from 'lucide-react';
import { motion } from 'framer-motion';

const TrendingAssetCard = ({ crypto, index }) => {
  const isPositive = crypto.change24h > 0;
  const formattedPrice = crypto.price >= 1 
    ? crypto.price.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })
    : crypto.price.toFixed(4);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: index * 0.1 }}
      viewport={{ once: true }}
      whileHover={{ scale: 1.05 }}
      className="trending-asset-card bg-card rounded-xl p-6 border border-border transition-all duration-300 hover:shadow-2xl hover:border-primary/30 cursor-pointer relative overflow-hidden group"
    >
      <div className="absolute inset-0 bg-gradient-to-br from-primary/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
      
      <div className="relative z-10">
        <div className="flex items-start justify-between mb-4">
          <div className="flex items-center gap-3">
            <div 
              className="w-12 h-12 rounded-full flex items-center justify-center text-2xl font-bold"
              style={{ 
                backgroundColor: `${crypto.color}20`,
                color: crypto.color,
              }}
            >
              {crypto.icon}
            </div>
            <div>
              <h3 className="text-lg font-bold">{crypto.name}</h3>
              <p className="text-sm text-muted-foreground">{crypto.symbol}</p>
            </div>
          </div>
          
          <div className={`flex items-center gap-1 px-2 py-1 rounded-lg ${
            isPositive ? 'bg-eco-green/10' : 'bg-destructive/10'
          }`}>
            {isPositive ? (
              <TrendingUp className="w-4 h-4 text-eco-green" />
            ) : (
              <TrendingDown className="w-4 h-4 text-destructive" />
            )}
          </div>
        </div>

        <div className="space-y-2">
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold price-text">${formattedPrice}</span>
          </div>
          
          <div className="flex items-center gap-2">
            <span className={`text-sm font-medium ${
              isPositive ? 'text-eco-green' : 'text-destructive'
            }`}>
              {isPositive ? '+' : ''}{crypto.change24h.toFixed(2)}%
            </span>
            <span className="text-xs text-muted-foreground">24h</span>
          </div>
        </div>
      </div>

      <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-primary/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
    </motion.div>
  );
};

export default TrendingAssetCard;