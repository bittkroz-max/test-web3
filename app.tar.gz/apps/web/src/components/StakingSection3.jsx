import React from 'react';
import { motion } from 'framer-motion';
import { useLanguage } from '@/i18n/LanguageContext.jsx';

const supportedAssets = [
  'Avalanche', 'Axelar', 'Cardano', 'Cosmos', 'Celo',
  'Ether', 'lsETH', 'Kusama', 'NEAR', 'Polkadot',
  'Polygon', 'Solana', 'Stacks', 'Sui', 'Tezos'
];

const StakingSection3 = () => {
  const { t } = useLanguage();
  return (
    <section className="py-20 bg-gradient-to-br from-secondary/5 via-background to-primary/5 border-y border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
          >
            <h2
              className="text-3xl md:text-4xl lg:text-5xl font-bold mb-6"
              style={{ letterSpacing: '-0.02em' }}
            >
              {t('Chancen mit mehreren Assets wachsen lassen', 'Grow opportunities with multiple assets')}
            </h2>
            <p className="text-lg leading-relaxed mb-8 max-w-prose">
              {t('Wir unterstützen Staking für über 15 führende Blockchain-Netzwerke und geben Ihnen die Flexibilität, Ihr Staking-Portfolio über mehrere Ökosysteme zu diversifizieren und Ihr Ertragspotenzial zu maximieren.', 'We support staking for 15+ leading blockchain networks, giving you the flexibility to diversify your staking portfolio across multiple ecosystems and maximize your earning potential.')}
            </p>

            <div className="mb-8">
              <h3 className="text-xl font-semibold mb-4">{t('Unterstützte Assets:', 'Supported Assets:')}</h3>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                {supportedAssets.map((asset, index) => (
                  <motion.div
                    key={asset}
                    initial={{ opacity: 0, scale: 0.9 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    transition={{ duration: 0.3, delay: index * 0.05 }}
                    viewport={{ once: true }}
                    className="bg-card border border-border rounded-lg px-3 py-2 text-sm font-medium text-center hover:border-primary/50 transition-all duration-200"
                  >
                    {asset}
                  </motion.div>
                ))}
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            viewport={{ once: true }}
            className="relative"
          >
            <img
              src="https://horizons-cdn.hostinger.com/203fccdc-e8bc-431c-9992-1395201ebaa1/696155958dc8be96ac2cba5f331201f0.png"
              alt={t('Handels-Dashboard mit mehreren Staking-Assets', 'Trading dashboard showing multiple staking assets')}
              className="w-full h-auto rounded-2xl shadow-2xl"
            />
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default StakingSection3;
