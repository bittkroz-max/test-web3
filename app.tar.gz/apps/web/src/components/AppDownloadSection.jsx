import React, { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Download, Smartphone, Share, PlusSquare, CheckCircle2 } from 'lucide-react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { getInstallState, subscribeInstallPrompt, triggerInstallPrompt } from '@/lib/installPromptStore';
import { useLanguage } from '@/i18n/LanguageContext.jsx';

function isStandaloneMode() {
  return (
    window.matchMedia?.('(display-mode: standalone)').matches ||
    window.navigator.standalone === true
  );
}

function detectIos() {
  return /iphone|ipad|ipod/i.test(window.navigator.userAgent) && !window.MSStream;
}

const AppDownloadSection = () => {
  const { t } = useLanguage();
  const [deferredEvent, setDeferredEvent] = useState(() => getInstallState().deferredPrompt);
  const [isIos, setIsIos] = useState(false);
  const [isInstalled, setIsInstalled] = useState(() => getInstallState().isInstalled);
  const [showIosInstructions, setShowIosInstructions] = useState(false);

  useEffect(() => {
    setIsIos(detectIos());

    const { deferredPrompt, isInstalled: storeInstalled } = getInstallState();
    setDeferredEvent(deferredPrompt);
    setIsInstalled(isStandaloneMode() || storeInstalled);

    const unsubscribe = subscribeInstallPrompt(({ deferredPrompt: nextPrompt, isInstalled: nextInstalled }) => {
      setDeferredEvent(nextPrompt);
      setIsInstalled(nextInstalled);
    });

    return unsubscribe;
  }, []);

  const handleInstallClick = async () => {
    if (isInstalled) return;

    if (deferredEvent) {
      const choice = await triggerInstallPrompt();
      if (choice?.outcome === 'accepted') {
        setIsInstalled(true);
      }
      setDeferredEvent(null);
      return;
    }

    if (isIos) {
      setShowIosInstructions(true);
      return;
    }

    setShowIosInstructions(true);
  };

  const containerVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.6,
        staggerChildren: 0.1,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 },
    },
  };

  return (
    <section className="py-20 bg-gradient-to-br from-primary/5 via-background to-secondary/5 border-y border-border">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: '-100px' }}
          className="text-center mb-16"
        >
          <motion.div variants={itemVariants} className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-6">
            <Smartphone className="w-4 h-4 text-primary" />
            <span className="text-sm font-medium text-primary">{t('Mobile App', 'Mobile App')}</span>
          </motion.div>

          <motion.h2
            variants={itemVariants}
            className="text-3xl md:text-4xl lg:text-5xl font-bold mb-6"
            style={{ letterSpacing: '-0.02em' }}
          >
            {t('Krypto von unterwegs handeln', 'Trade crypto on the go')}
          </motion.h2>

          <motion.p
            variants={itemVariants}
            className="text-lg md:text-xl leading-relaxed max-w-2xl mx-auto text-foreground/80"
          >
            {t('Installieren Sie die delfinitx-App direkt von dieser Website. Greifen Sie auf Ihr Portfolio zu, überwachen Sie Live-Kurse und handeln Sie jederzeit, überall mit professionellen Werkzeugen.', 'Install the delfinitx app directly from this site. Access your portfolio, monitor live prices, and trade anytime, anywhere with professional-grade tools at your fingertips.')}
          </motion.p>
        </motion.div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: '-100px' }}
          className="flex flex-col items-center justify-center gap-6"
        >
          {isInstalled ? (
            <motion.div
              variants={itemVariants}
              className="flex items-center gap-3 px-6 py-4 rounded-xl bg-secondary/10 border border-secondary/30"
            >
              <CheckCircle2 className="w-5 h-5 text-secondary" />
              <span className="font-medium text-secondary">{t('delfinitx ist auf diesem Gerät bereits installiert', 'delfinitx is already installed on this device')}</span>
            </motion.div>
          ) : (
            <motion.button
              variants={itemVariants}
              onClick={handleInstallClick}
              className="group relative w-full sm:w-auto px-10 py-5 rounded-xl bg-foreground text-background font-semibold transition-all duration-300 overflow-hidden"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.98 }}
            >
              <div className="absolute inset-0 bg-gradient-to-r from-primary/20 to-secondary/20 opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              <div className="relative flex items-center justify-center gap-3">
                <Download className="w-6 h-6" strokeWidth={2} />
                <div className="text-left">
                  <div className="text-xs opacity-90">{isIos ? t('Zum Startbildschirm hinzufügen', 'Add to Home Screen') : t('Jetzt installieren', 'Install now')}</div>
                  <div className="text-lg font-bold">{t('delfinitx App installieren', 'Install delfinitx App')}</div>
                </div>
              </div>
            </motion.button>
          )}
        </motion.div>

        {/* Feature highlights */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: '-100px' }}
          className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-6"
        >
          <motion.div
            variants={itemVariants}
            className="p-6 rounded-lg bg-card border border-border/50 hover:border-primary/30 transition-colors duration-300"
          >
            <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
              <Download className="w-5 h-5 text-primary" />
            </div>
            <h3 className="font-semibold mb-2">{t('Einfache Installation', 'Easy Installation')}</h3>
          </motion.div>

          <motion.div
            variants={itemVariants}
            className="p-6 rounded-lg bg-card border border-border/50 hover:border-primary/30 transition-colors duration-300"
          >
            <div className="w-10 h-10 rounded-lg bg-secondary/10 flex items-center justify-center mb-4">
              <Smartphone className="w-5 h-5 text-secondary" />
            </div>
            <h3 className="font-semibold mb-2">{t('Alle Funktionen', 'Full Features')}</h3>
            <p className="text-sm text-foreground/70">
              {t('Zugriff auf alle Handelswerkzeuge, Live-Kurse und Portfolioverwaltung auf dem Smartphone.', 'Access all trading tools, real-time prices, and portfolio management on mobile.')}
            </p>
          </motion.div>

          <motion.div
            variants={itemVariants}
            className="p-6 rounded-lg bg-card border border-border/50 hover:border-primary/30 transition-colors duration-300"
          >
            <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center mb-4">
              <svg className="w-5 h-5 text-primary" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M5.293 7.707a1 1 0 010-1.414l4-4a1 1 0 011.414 0l4 4a1 1 0 01-1.414 1.414L11 5.414V12a1 1 0 11-2 0V5.414L6.707 7.707a1 1 0 01-1.414 0z" clipRule="evenodd" />
              </svg>
            </div>
            <h3 className="font-semibold mb-2">{t('Immer aktuell', 'Always Updated')}</h3>
            <p className="text-sm text-foreground/70">
              {t('Automatische Updates sorgen stets für die neuesten Funktionen und Sicherheits-Patches.', 'Automatic updates ensure you always have the latest features and security patches.')}
            </p>
          </motion.div>
        </motion.div>
      </div>

      <Dialog open={showIosInstructions} onOpenChange={setShowIosInstructions}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Smartphone className="w-5 h-5 text-primary" />
              {t('delfinitx installieren', 'Install delfinitx')}
            </DialogTitle>
            <DialogDescription>
              {isIos
                ? t('Fügen Sie delfinitx zum Startbildschirm hinzu für ein vollflächiges, app-ähnliches Erlebnis.', 'Add delfinitx to your Home Screen for a full-screen, app-like experience.')
                : t('Ihr Browser hat den Installationshinweis noch nicht angeboten. Sie können delfinitx dennoch über das Browser-Menü hinzufügen.', 'Your browser hasn\u2019t offered the install prompt yet. You can still add delfinitx from the browser menu.')}
            </DialogDescription>
          </DialogHeader>

          {isIos ? (
            <ol className="space-y-4 mt-2">
              <li className="flex items-start gap-3">
                <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-primary/10 text-sm font-semibold text-primary">1</span>
                <p className="text-sm text-foreground/90 pt-0.5">
                  {t('Tippen Sie auf die ', 'Tap the ')}<Share className="inline h-4 w-4 -mt-0.5 mx-0.5" strokeWidth={2} /> {t(' Teilen-Schaltfläche in der Safari-Symbolleiste.', 'Share button in Safari\'s toolbar.')}
                </p>
              </li>
              <li className="flex items-start gap-3">
                <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-primary/10 text-sm font-semibold text-primary">2</span>
                <p className="text-sm text-foreground/90 pt-0.5">
                  {t('Scrollen Sie nach unten und tippen Sie auf ', 'Scroll down and tap ')}<span className="inline-flex items-center gap-1 font-medium text-foreground"><PlusSquare className="h-4 w-4" strokeWidth={2} /> {t('Zum Startbildschirm hinzufügen', 'Add to Home Screen')}</span>.
                </p>
              </li>
              <li className="flex items-start gap-3">
                <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-primary/10 text-sm font-semibold text-primary">3</span>
                <p className="text-sm text-foreground/90 pt-0.5">
                  {t('Tippen Sie auf ', 'Tap ')}<span className="font-medium text-foreground">{t('Hinzufügen', 'Add')}</span>{t(', um abzuschließen – delfinitx erscheint auf Ihrem Startbildschirm.', ' to finish — delfinitx will appear on your Home Screen.')}
                </p>
              </li>
            </ol>
          ) : (
            <ol className="space-y-4 mt-2">
              <li className="flex items-start gap-3">
                <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-primary/10 text-sm font-semibold text-primary">1</span>
                <p className="text-sm text-foreground/90 pt-0.5">
                  {t('Öffnen Sie das Menü Ihres Browsers (meist das ', 'Open your browser\'s menu (usually the ')}<span className="font-medium text-foreground">⋮</span>{t('-Symbol).', ' icon).')}
                </p>
              </li>
              <li className="flex items-start gap-3">
                <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-primary/10 text-sm font-semibold text-primary">2</span>
                <p className="text-sm text-foreground/90 pt-0.5">
                  {t('Wählen Sie ', 'Select ')}<span className="font-medium text-foreground">{t('App installieren', 'Install app')}</span> {t('oder ', 'or ')}<span className="font-medium text-foreground">{t('Zum Startbildschirm hinzufügen', 'Add to Home screen')}</span>.
                </p>
              </li>
              <li className="flex items-start gap-3">
                <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-primary/10 text-sm font-semibold text-primary">3</span>
                <p className="text-sm text-foreground/90 pt-0.5">
                  {t('Bestätigen Sie die Installation – delfinitx wird Ihrem Gerät hinzugefügt.', 'Confirm the install — delfinitx will be added to your device.')}
                </p>
              </li>
            </ol>
          )}
        </DialogContent>
      </Dialog>
    </section>
  );
};

export default AppDownloadSection;
