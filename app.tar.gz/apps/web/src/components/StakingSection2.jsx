import React from 'react';
import { motion } from 'framer-motion';
import { Droplet, Shield, Server, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useLanguage } from '@/i18n/LanguageContext.jsx';

const StakingSection2 = () => {
  const { t } = useLanguage();
  const features = [
    {
      icon: Droplet,
      title: t('Liquid Staking', 'Liquid Staking'),
      description: t('Liquidität erhalten und gleichzeitig Staking-Belohnungen mit tokenisierten gestakten Assets verdienen', 'Maintain liquidity while earning staking rewards with tokenized staked assets'),
    },
    {
      icon: Shield,
      title: t('Traditionelles Staking', 'Traditional Staking'),
      description: t('Assets für feste Zeiträume sperren und wettbewerbsfähige APY-Raten verdienen', 'Lock your assets for fixed periods and earn competitive APY rates'),
    },
    {
      icon: Server,
      title: t('Validator betreiben', 'Validator Running'),
      description: t('Einen eigenen Validator-Knoten betreiben und maximale Belohnungen mit voller Kontrolle verdienen', 'Run your own validator node and earn maximum rewards with full control'),
    },
  ];

  return (
    <section className="py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            viewport={{ once: true }}
            className="order-2 lg:order-1"
          >
            <img
              src="https://horizons-cdn.hostinger.com/203fccdc-e8bc-431c-9992-1395201ebaa1/b9c49d96c49898d671f7e8bff8261a31.png"
              alt={t('Mobile Wallet-Oberfläche mit Staking-Optionen', 'Mobile wallet interface showing staking options')}
              className="w-full h-auto rounded-2xl"
            />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            viewport={{ once: true }}
            className="order-1 lg:order-2"
          >
            <h2
              className="text-3xl md:text-4xl lg:text-5xl font-bold mb-6"
              style={{ letterSpacing: '-0.02em' }}
            >
              {t('Die richtige Staking-Lösung finden', 'Find the right staking solution')}
            </h2>
            <p className="text-lg leading-relaxed mb-8 max-w-prose">
              {t('Wählen Sie zwischen Liquid Staking für Flexibilität, traditionellem Staking für maximale Belohnungen oder dem Betrieb eines eigenen Validators für volle Kontrolle. Jede Option ist auf Ihre Anlagestrategie und Risikobereitschaft zugeschnitten.', 'Choose between liquid staking for flexibility, traditional staking for maximum rewards, or run your own validator for complete control. Each option is designed to fit your investment strategy and risk tolerance.')}
            </p>

            <div className="space-y-6 mb-8">
              {features.map((feature, index) => {
                const Icon = feature.icon;
                return (
                  <motion.div
                    key={feature.title}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.5, delay: 0.3 + index * 0.1 }}
                    viewport={{ once: true }}
                    className="flex gap-4"
                  >
                    <div className="flex-shrink-0">
                      <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
                        <Icon className="w-6 h-6 text-primary" />
                      </div>
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold mb-1">{feature.title}</h3>
                      <p className="text-sm leading-relaxed">{feature.description}</p>
                    </div>
                  </motion.div>
                );
              })}
            </div>

            <Button
              variant="outline"
              size="lg"
              className="gap-2 transition-all duration-200 active:scale-[0.98]"
            >
              {t('Mehr erfahren', 'Learn More')}
              <ArrowRight className="w-5 h-5" />
            </Button>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default StakingSection2;
