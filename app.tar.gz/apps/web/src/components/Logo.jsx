import React from 'react';
import { TrendingUp } from 'lucide-react';

const Logo = ({ className = '' }) => {
  return (
    <div className={`flex items-center gap-2 ${className}`}>
      <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center group-hover:bg-primary/20 transition-all duration-200">
        <TrendingUp className="w-6 h-6 text-primary" />
      </div>
      <span className="text-xl font-bold">delfinitx</span>
    </div>
  );
};

export default Logo;