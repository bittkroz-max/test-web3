import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowRight, ArrowLeft, Clock, Calendar } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import { useLanguage } from '@/i18n/LanguageContext.jsx';

const GuideArticleLayout = ({
  metaTitle,
  metaDescription,
  category,
  difficulty,
  readingTime,
  date,
  title,
  intro,
  heroImage,
  heroAlt,
  sections,
  ctaTitle,
  ctaDescription,
}) => {
  const { t } = useLanguage();
  return (
    <>
      <Helmet>
        <title>{metaTitle}</title>
        <meta name="description" content={metaDescription} />
      </Helmet>

      <div className="min-h-screen flex flex-col">
        <Header />

        <main className="flex-1">
          <section className="relative overflow-hidden">
            <div className="absolute inset-0 z-0">
              <img
                src={heroImage}
                alt={heroAlt}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-b from-background/70 via-background/85 to-background" />
            </div>

            <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 pt-16 pb-20">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
              >
                <Link
                  to="/guides"
                  className="inline-flex items-center gap-2 text-sm font-medium text-primary mb-6 group"
                >
                  <ArrowLeft className="w-4 h-4 transition-transform duration-300 group-hover:-translate-x-1" />
                  {t('Zurück zu den Leitfäden', 'Back to Guides')}
                </Link>

                <div className="flex flex-wrap items-center gap-3 mb-6">
                  <Badge className="bg-primary/15 text-primary border border-primary/30 text-xs font-medium">
                    {category}
                  </Badge>
                  <Badge className="bg-secondary/15 text-secondary border border-secondary/30 text-xs font-medium">
                    {difficulty}
                  </Badge>
                  <div className="flex items-center gap-1 text-xs text-muted-foreground">
                    <Clock className="w-3.5 h-3.5" />
                    <span>{readingTime} {t('Min. Lesezeit', 'min read')}</span>
                  </div>
                  <div className="flex items-center gap-1 text-xs text-muted-foreground">
                    <Calendar className="w-3.5 h-3.5" />
                    <span>{date}</span>
                  </div>
                </div>

                <h1
                  className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight mb-6"
                  style={{ letterSpacing: '-0.02em' }}
                >
                  {title}
                </h1>
                <p className="text-lg md:text-xl leading-relaxed max-w-2xl">
                  {intro}
                </p>
              </motion.div>
            </div>
          </section>

          <section className="py-16 md:py-20">
            <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
              {sections.map((section, index) => (
                <motion.div
                  key={section.heading}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.5, delay: index * 0.05 }}
                  viewport={{ once: true }}
                  className="mb-14"
                >
                  <div className="flex items-start gap-4 mb-4">
                    {section.icon && (
                      <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center flex-shrink-0">
                        <section.icon className="w-6 h-6 text-primary" />
                      </div>
                    )}
                    <div>
                      <h2
                        className="text-2xl md:text-3xl font-bold mb-1"
                        style={{ letterSpacing: '-0.01em' }}
                      >
                        {section.heading}
                      </h2>
                      {section.subheading && (
                        <p className="text-sm text-muted-foreground">
                          {section.subheading}
                        </p>
                      )}
                    </div>
                  </div>

                  <div className="space-y-4 max-w-prose">
                    {section.paragraphs.map((para, pIndex) => (
                      <p key={pIndex} className="text-base leading-relaxed">
                        {para}
                      </p>
                    ))}
                  </div>

                  {section.list && (
                    <ul className="mt-4 space-y-3">
                      {section.list.map((item, lIndex) => (
                        <li key={lIndex} className="flex items-start gap-3">
                          <div className="w-1.5 h-1.5 rounded-full bg-primary mt-2.5 flex-shrink-0" />
                          <span className="text-base leading-relaxed">
                            <strong className="font-semibold">{item.title}</strong>
                            {item.description ? ` — ${item.description}` : ''}
                          </span>
                        </li>
                      ))}
                    </ul>
                  )}
                </motion.div>
              ))}

              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
                viewport={{ once: true }}
                className="rounded-2xl border border-primary/20 bg-gradient-to-br from-primary/10 to-secondary/5 p-8 md:p-10 text-center"
              >
                <h3 className="text-2xl md:text-3xl font-bold mb-3" style={{ letterSpacing: '-0.01em' }}>
                  {ctaTitle}
                </h3>
                <p className="text-base md:text-lg leading-relaxed max-w-xl mx-auto mb-6">
                  {ctaDescription}
                </p>
                <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                  <Button asChild size="lg" className="gap-2 transition-all duration-200 active:scale-[0.98]">
                    <Link to="/signup">
                      {t('Jetzt starten', 'Get Started')}
                      <ArrowRight className="w-5 h-5" />
                    </Link>
                  </Button>
                  <Button asChild variant="outline" size="lg" className="transition-all duration-200 active:scale-[0.98]">
                    <Link to="/guides">{t('Weitere Leitfäden entdecken', 'Explore More Guides')}</Link>
                  </Button>
                </div>
              </motion.div>
            </div>
          </section>
        </main>

        <Footer />
      </div>
    </>
  );
};

export default GuideArticleLayout;
