import React from 'react';
import { motion } from 'framer-motion';
import TrendingAssetCard from '@/components/TrendingAssetCard.jsx';
import { trendingCryptos } from '@/data/trendingCryptos.js';
import { useLanguage } from '@/i18n/LanguageContext.jsx';

const TrendingAssets = () => {
  const { t } = useLanguage();
  return (
    <section className="py-20 bg-gradient-to-br from-background via-muted/30 to-background">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
          className="text-center mb-12"
        >
          <h2
            className="text-3xl md:text-4xl lg:text-5xl font-bold mb-4"
            style={{ letterSpacing: '-0.02em' }}
          >
            {t('Trend-Assets', 'Trending Assets')}
          </h2>
          <p className="text-lg md:text-xl leading-relaxed max-w-2xl mx-auto">
            {t('Die beliebtesten Kryptowährungen im Moment', 'Most popular cryptocurrencies right now')}
          </p>
        </motion.div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {trendingCryptos.map((crypto, index) => (
            <TrendingAssetCard key={crypto.id} crypto={crypto} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default TrendingAssets;
