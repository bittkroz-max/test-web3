import React from 'react';

const PALETTE = {
  orange: '#F7931A',
  blue: '#3B82F6',
  slate: '#1F2937',
};

const CertBadge = ({ id, topText, line1, line2, ribbonText, ribbonColor, accentColor }) => {
  const arcId = `cert-arc-${id}`;

  return (
    <svg
      viewBox="0 0 180 200"
      className="w-full h-full"
      role="img"
      aria-label={`${topText} ${line1} ${line2} ${ribbonText}`}
    >
      <defs>
        <path id={arcId} d="M 24 78 A 66 66 0 1 1 156 78" fill="none" />
      </defs>

      {/* Outer ring */}
      <circle cx="90" cy="86" r="68" fill="white" stroke={PALETTE.slate} strokeWidth="2.5" />
      <circle cx="90" cy="86" r="58" fill="none" stroke={accentColor} strokeWidth="1.5" opacity="0.35" />

      {/* Curved top text */}
      <text
        fill={PALETTE.slate}
        fontSize="9.5"
        fontWeight="700"
        letterSpacing="1.5"
        style={{ fontFamily: 'DM Sans, sans-serif' }}
      >
        <textPath href={`#${arcId}`} startOffset="50%" textAnchor="middle">
          {topText}
        </textPath>
      </text>

      {/* Simple globe/mark icon */}
      <g transform="translate(90,60)" opacity="0.9">
        <circle r="9" fill="none" stroke={accentColor} strokeWidth="1.6" />
        <line x1="-9" y1="0" x2="9" y2="0" stroke={accentColor} strokeWidth="1.2" />
        <path d="M -6 -6 Q 0 0 -6 6" fill="none" stroke={accentColor} strokeWidth="1.1" />
        <path d="M 6 -6 Q 0 0 6 6" fill="none" stroke={accentColor} strokeWidth="1.1" />
      </g>

      {/* Main bold lines */}
      <text
        x="90"
        y="94"
        textAnchor="middle"
        fill={PALETTE.slate}
        fontSize="20"
        fontWeight="800"
        style={{ fontFamily: 'DM Sans, sans-serif' }}
      >
        {line1}
      </text>
      <text
        x="90"
        y="115"
        textAnchor="middle"
        fill={PALETTE.slate}
        fontSize="15"
        fontWeight="700"
        style={{ fontFamily: 'DM Sans, sans-serif' }}
      >
        {line2}
      </text>

      {/* Ribbon */}
      <g>
        <polygon points="18,150 42,150 30,162" fill={ribbonColor} opacity="0.85" />
        <polygon points="138,150 162,150 150,162" fill={ribbonColor} opacity="0.85" />
        <rect x="24" y="140" width="132" height="24" rx="2" fill={ribbonColor} />
        <text
          x="90"
          y="157"
          textAnchor="middle"
          fill="white"
          fontSize="11.5"
          fontWeight="800"
          letterSpacing="1.5"
          style={{ fontFamily: 'DM Sans, sans-serif' }}
        >
          {ribbonText}
        </text>
      </g>
    </svg>
  );
};

const CertificationBadges = () => {
  const badges = [
    {
      id: 'soc2',
      topText: 'SERVICE ORGANIZATION CONTROL',
      line1: 'SOC2',
      line2: 'AICPA',
      ribbonText: 'COMPLIANT',
      ribbonColor: PALETTE.orange,
      accentColor: PALETTE.orange,
    },
    {
      id: 'iso27001',
      topText: 'INFORMATION SECURITY MANAGEMENT',
      line1: 'ISO',
      line2: '27001',
      ribbonText: 'CERTIFIED',
      ribbonColor: PALETTE.blue,
      accentColor: PALETTE.blue,
    },
    {
      id: 'iso27017',
      topText: 'INFORMATION SECURITY MANAGEMENT',
      line1: 'ISO',
      line2: '27017',
      ribbonText: 'CERTIFIED',
      ribbonColor: PALETTE.blue,
      accentColor: PALETTE.blue,
    },
    {
      id: 'iso9001',
      topText: 'QUALITY MANAGEMENT SYSTEM',
      line1: 'ISO',
      line2: '9001',
      ribbonText: 'CERTIFIED',
      ribbonColor: PALETTE.slate,
      accentColor: PALETTE.slate,
    },
  ];

  return (
    <div className="flex flex-wrap items-center gap-6 sm:gap-8">
      {badges.map((badge) => (
        <div key={badge.id} className="w-20 h-24 sm:w-24 sm:h-28 flex-shrink-0">
          <CertBadge {...badge} />
        </div>
      ))}
    </div>
  );
};

export default CertificationBadges;
